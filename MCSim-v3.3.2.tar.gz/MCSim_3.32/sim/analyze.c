/* analyze.c
 
   written by D.R.Maszle
   21 January 1992
 
   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.analyze.c
    Revision:  1.2
        Date:  8/11/93
     Modtime:  17:04:27
      Author:  @a
   -- SCCS  ---------
 
*/
   

#include "sim.h"


#define P_VAL(pos, j, k) (&(pos)->prgdOutputVals[j][k])


void OutspecToLinearArray (PANALYSIS panal, PMCDATAOUT pMCDataOut)
{
  POUTSPEC pos;
  long i, j, k;

  pMCDataOut->nbrdy2 = 0;
  for (i = 0; i < panal->expGlobal.iExp; i++)		/* Each experiment */

    for (j = 0,						/* Each variable */
	 pos = &panal->rgpExps[i]->os; j < pos->nOutputs; j++)

      for (k = 0; k < pos->pcOutputTimes[j]; k++)	/* Each output time */
	pMCDataOut->data[pMCDataOut->nbrdy2++] = *P_VAL(pos, j, k);

  pMCDataOut->nbrdy3 = pMCDataOut->nbrdy2; /* no extra data computed */

} /* OutspecToLinearArray */


/* TransformData */
   
void TransformData (PANALYSIS panal, PMCDATAOUT pMCDataOut)
{

  OutspecToLinearArray (panal, pMCDataOut);

}  /* TransformData */

