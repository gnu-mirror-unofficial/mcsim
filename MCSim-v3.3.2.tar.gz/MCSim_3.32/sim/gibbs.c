/* gibbs.c
 
   written by D.R.Maszle
   16 August 1993
 
   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.gibbs.c
    Revision:  1.3
        Date:  8/16/93
     Modtime:  19:25:02
      Author:  D.R.Maszle
   -- SCCS  ---------
 
*/

#include "sim.h"

void DoGibbsEstimation (PANALYSIS panal)
{
  ;
}  /* DoGibbsEstimation */
