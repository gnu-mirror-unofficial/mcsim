/* matutil.h

   written by Don Robert Maszle
   18 September 1992
   
   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.matutil.h
    Revision:  1.1
        Date:  7/14/93
     Modtime:  19:15:03
      Author:  @a
   -- SCCS  ---------

*/


/*-- Macros -----*/

#define NewVector(type, size) ((type *) malloc((size)*sizeof(type)))


/*-- Prototypes -----*/
  
void ColumnMeans (long cRows, long cCols, double **x, double *x_bar);

double **InitVectorsVector (double **rgpIn, long cVectors, long cElemsEach);

double *LogTransformArray (long nElems, double *rgdSrc, double *rgdDes);

    /*-- Write an array to a file */
void WriteArray (FILE *pfile, long cElems, double *rg);

    /*-- Write the array, exp() transformed, to a file, i.e. exp(a[.])*/
void WriteArrayExp (FILE *pfile, long cElems, double *rg);

    /*-- For debugging */
void _walog (long cElems, double *rg);
