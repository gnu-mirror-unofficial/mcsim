/* matutil.h

   written by Don Robert Maszle
   18 September 1992

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.matutil.h
    Revision:  1.5
        Date:  28 Jan 1995
     Modtime:  03:43:45
      Author:  @a
   -- SCCS  ---------

*/


/* -----------------------------------------------------------------------------
   Prototypes */

int    Cholesky (PDOUBLE *prgdVariance, PDOUBLE *prgdComponent, long lNparams);

void   ColumnMeans (long cRows, long cCols, double **x, double *x_bar);

double **InitdMatrix (long cVectors, long cElemsEach);

long   **InitlMatrix (long cVectors, long cElemsEach);

double *InitdVector (long cVectors);

int    *InitiVector (long cVectors);

long   *InitlVector (long cVectors);

double **InitpdVector (long cVectors);

double *LogTransformArray (long nElems, double *rgdSrc, double *rgdDes);

/* End */

