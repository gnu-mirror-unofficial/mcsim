/* simmonte.h

   originally written by Frederic Bois

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.simmonte.h
    Revision:  1.5
        Date:  10 Sep 1995
     Modtime:  03:47:03
      Author:  @a
   -- SCCS  ---------

   Header file for simmonte.c
*/

/* -----------------------------------------------------------------------------
   Prototypes */

void CalcMCParms (PMONTECARLO pMC, double rgParms[], long iStart);
int  CalculateOneMCParm (PMCVAR pMCVar, PMONTECARLO pMC);
BOOL GetMCMods (PANALYSIS panal, double rgdOptionalParms[]);
void ModifyMCParms (PMONTECARLO pMC);
int  ModifyOneMCParm (PVOID pData, PVOID pInfo);
BOOL InitSetPoints (PMONTECARLO pMC);
BOOL ReadSetPoints (PMONTECARLO pMC, double rgParms[]);
void SetParms (long cParms, HVAR *rghvar, double *rgdParm);
void SetParmsLog (long cParms, HVAR *rghvar, double *rgdParm);

/* End */

