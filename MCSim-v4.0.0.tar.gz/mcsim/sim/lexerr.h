/* lexerr.h

   written by Don Maszle
   13 October 1991

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.lexerr.h
    Revision:  1.5
        Date:  23 Nov 1996
     Modtime:  12:38:49
      Author:  @a
   -- SCCS  ---------

   Header file for error reporting routine of lexerr.c
*/

#ifndef _LEXERR_H_

/* ----------------------------------------------------------------------------
   Inclusions  */

#include "hungtype.h"
#include "lex.h"
#include "sim.h"

/* ----------------------------------------------------------------------------
   Prototypes */

void ReportError (PINPUTBUF, WORD, PSTR, PSTR);
void ReportRunTimeError (PANALYSIS, WORD, ...);

#define _LEXERR_H_
#endif

/* End */


