/* mac.h

   written by Frederic Bois
   4 September 1995

   Copyright (c) 1995.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  %F%
    Revision:  %I%
        Date:  %G%
     Modtime:  %U%
      Author:  @a
   -- SCCS  ---------

*/


/* ----------------------------------------------------------------------------
   Prototypes */

/* Public */


/* Private */

#ifdef _MACOS_
/*
void AdjustMenus(void);
void FileError(Str255 s, Str255 f);
void HandleEvent(void);
void HandleMenu(long mSelect);
void HandleMouseDown(EventRecord  *theEvent);
void InitMacintosh( void );
void Main_for_mac(void);
int  OpenOutFile(Str255 fn, int *vRef);
int  OpenSimFile(Str255 fn, int *vRef);
void pStrCopy(StringPtr a, StringPtr b);
void SetUpMenus(void);
void ShowSplash (void);


static void Enable (MenuHandle menu, short item, short ok);
*/
#endif

/* End */

