/* matutil.h

   written by Don Robert Maszle
   18 September 1992

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.matutilo.h
    Revision:  1.4
        Date:  28 Jan 1995
     Modtime:  03:43:48
      Author:  @a
   -- SCCS  ---------

*/


/* Prototypes */

/* Write an array to a file */
void WriteArray (FILE *pfile, long cElems, double *rg);

/* Write the array, exp() transformed, to a file, i.e. exp(a[.])*/
void WriteArrayExp (FILE *pfile, long cElems, double *rg);

/* For debugging */
void _walog (long cElems, double *rg);

/* End */

