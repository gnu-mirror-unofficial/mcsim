/* simmonte.h

   originally written by Frederic Bois

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  %F%
    Revision:  %I%
        Date:  %G%
     Modtime:  %U%
      Author:  @a
   -- SCCS  ---------

   Header file for simmonte.c
*/

/* -----------------------------------------------------------------------------
   Prototypes */

void CalcMCParms (PMONTECARLO pMC, double rgParms[], long iStart);
int  CalculateOneMCParm (PMCVAR pMCVar);
double GetParm (PMCVAR pMCVar, int iIndex);
BOOL GetMCMods (PANALYSIS panal, double rgdOptionalParms[]);
BOOL InitSetPoints (PMONTECARLO pMC);
BOOL ReadSetPoints (PMONTECARLO pMC, double rgParms[]);
void SetParms (long cParms, HVAR *rghvar, double *rgdParm);

/* End */

