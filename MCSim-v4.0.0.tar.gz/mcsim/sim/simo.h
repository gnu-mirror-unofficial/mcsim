/* simo.h

   originally written by Frederic Bois

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   -- Revisions -----
     Logfile:  SCCS/s.simo.h
    Revision:  1.5
        Date:  30 Jan 1995
     Modtime:  09:26:16
      Author:  @a
   -- SCCS  ---------

   Header file for simo.c
*/

#ifndef _SIMO_H_
#define _SIMO_H_

/* -----------------------------------------------------------------------------
   Inclusions
*/

#include "yourcode.h"
#include "sim.h"


/* -----------------------------------------------------------------------------
   Prototypes
*/

void CloseMCFiles (PANALYSIS);
void SaveOutputs (PEXPERIMENT, PDOUBLE);
void NextOutputTime (PEXPERIMENT, PDOUBLE, PINT);
int OpenMCFiles (PANALYSIS panal);
void WriteMCHeader (PFILE, PANALYSIS);
void WriteMCOutput (PANALYSIS, PMCPREDOUT);
void WriteNormalOutput (PANALYSIS, PEXPERIMENT);
int  WriteOneMod (PVOID, PVOID);

#endif /* _SIMO_H_ */

/* End */

