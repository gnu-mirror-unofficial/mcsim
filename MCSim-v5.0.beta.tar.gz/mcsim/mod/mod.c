/* mod.c

   written by Don Maszle
   15 September 1991
   
   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

   -- Revisions -----
     Logfile:  %F%
    Revision:  %I%
        Date:  %G%
     Modtime:  %U%
      Author:  @a
   -- SCCS  ---------

   Entry point for model code generator.

   Calls ReadModel() to define the model and WriteModel() to create
   the output file.
   
   The INPUTINFO struct is defined as follows:
     
     wContext	:	A flag for the current context of the input. 

     pvmGloVars :       Vars of type ID_LOCAL* are accessible
                        only within the respective section.  If
		        states are given a value outside of the
			Dynamics section, it is used as an INITIAL
			value, otherwise they are initialized to 0.0. 

     pvmDynEqns:	List of equations to go into the CalcDeriv(),
     pvmJacobEqns:	Jacobian(), and ScaleModel() routines, respectively.
     pvmScaleEqns:	The LHS of equations of state variables in Dynamics
			are actually dt().  The hType field gives the type of
			the LHS and also a flag for space in the uppermost
			bit.
     pvmCalcOutEqns:    List of equations to into CalcOutputs().  These
                        can be used to scale output variables *only*.
                        The routinine is called just be outputting
                        values specified in Print().
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "mod.h"
#include "modi.h"
#include "modo.h"

/***********************************************************************
   main -- Entry point for the PBPK simulation model preprocessor
   
*/

int main (int nArg, PSTR rgszArg[])
{
  INPUTINFO info;

  printf ("\n________________________________________\n");
  printf ("\nMod - Model Generator Program " VSZ_VERSION "\n\n");
  printf (VSZ_COPYRIGHT "\n\n");

  printf ("MCSim comes with ABSOLUTELY NO WARRANTY;\n"
          "This is free software, and you are welcome to redistribute it\n"
          "under certain conditions; see the GNU General Public License.\n\n");

#ifdef _MACOS_
  /* for the Macintosh there are no command line parameters 
     so we input them at the console
   */
  rgszArg[1] = (PSTR) calloc (1, 80);
  printf ("Model definition file? ");
  scanf ("%[^:\f\r\v\n]", rgszArg[1]);
  nArg = 2;
#endif

  if (nArg == 2 || nArg == 3 ) {
    ReadModel (&info, rgszArg[1]);
    WriteModel (&info, nArg, rgszArg);    
  }
  else {
    printf ("Usage: %s  [input-file  [output-file]]\n", rgszArg[0]);
    printf ("  Creates file 'model.c' according to input-file specs\n");
  }

  return 0;
  
} /* main */
