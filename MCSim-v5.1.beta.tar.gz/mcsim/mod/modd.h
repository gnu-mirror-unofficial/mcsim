/* modd.h

   written by Frederic Bois
   27 November 1997

   Copyright (c) 1993.  Don Maszle, Frederic Bois.  All rights reserved.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

   -- Revisions -----
     Logfile:  %F%
    Revision:  %I%
        Date:  %G%
     Modtime:  %U%
      Author:  @a
   -- SCCS  ---------

   Header file for modd.c.
*/

#ifndef _MODD_H_


/* ---------------------------------------------------------------------------
   Prototypes */

void AddEquation (PVMMAPSTRCT *ppvm, PSTR szName, PSTR szEqn, HANDLE hType);
HANDLE CalculateVarHandle (PVMMAPSTRCT pvm, PSTR sz);
PSTR CopyString (PSTR szOrg);
void DeclareModelVar (PINPUTBUF pibIn, PSTR szName, int iKWCode);
void DefineCalcOutEqn (PINPUTBUF pibIn, PSTR szName, PSTR szEqn, HANDLE hType);
void DefineDynamicsEqn (PINPUTBUF pibIn, PSTR szName, PSTR szEqn, 
                        HANDLE hType);
void DefineGlobalVar (PINPUTBUF pibIn, PVMMAPSTRCT pvm, PSTR szName, 
                      PSTR szEqn, HANDLE hType);
void DefineJacobEqn (PINPUTBUF pibIn, PSTR szName, PSTR szEqn, HANDLE hType);
void DefineScaleEqn (PINPUTBUF pibIn, PSTR szName, PSTR szEqn, HANDLE hType);
void DefineVariable (PINPUTBUF pibIn, PSTR szName, PSTR szEqn, int iKWCode);
PVMMAPSTRCT GetVarPTR (PVMMAPSTRCT pvm, PSTR szName);
int  GetVarType (PVMMAPSTRCT pvm, PSTR szName);
BOOL IsMathFunc (PSTR sz);
void SetEquation (PVMMAPSTRCT pvm, PSTR szEqn);
void SetVarType (PVMMAPSTRCT pvm, PSTR szName, HANDLE hType);
BOOL VerifyEqn (PINPUTBUF pibIn, PSTR szEqn);

#define _MODD_H_
#endif

/* End */


