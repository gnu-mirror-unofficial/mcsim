/* modiSBML.h

   Copyright (c) 2007-2008. Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, 5th Floor, Boston, MA 02110-1301, USA.

   -- Revisions -----
     Logfile:  %F%
    Revision:  %I%
        Date:  %G%
     Modtime:  %U%
      Author:  @a
   -- SCCS  ---------

   Header file for main parsing routines.
*/

#ifndef _MODISBML_H_

/* ----------------------------------------------------------------------------
   Inclusions
*/


/* ----------------------------------------------------------------------------
   Public Definitions
*/

#define MAX_ARGS 25


/* ----------------------------------------------------------------------------
   Public Constants
*/

/* SBML Context Types, to define SBML sections */

#define CN_SBML          1
#define CN_APPLY         1

/* ---------------------------------------------------------------------------
   Public Typedefs */


/* ---------------------------------------------------------------------------
   Prototypes */

int  GetSBMLKeywordCode (PSTR szKeyword);
void ReadApply (PINPUTBUF pibIn, PINT bInited, PSTR toto);
void ReadSBMLModels (PINPUTBUF pibIn);
void ReadPKTemplate (PINPUTBUF pibIn);

#define _MODISBML_H_
#endif

/* End */
