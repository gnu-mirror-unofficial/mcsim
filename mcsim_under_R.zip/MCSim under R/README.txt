==============================================
GNU MCSim and R (even under Microsoft Windows)
----------------------------------------------

The basic tools needed to build and run GNU MCSim are not available to
many users of Windows systems. Fortunately, the R software (see
http://www.r-project.org/), when installed with its Rtools (this
typically requires administrator's right to do) can compile and run
GNU MCSim models. 

We have developed C code in the GNU MCSim utility "mod" and R scripts
to compile GNU MCSim models to C code usable by the R package
deSolve. That requires calling the GNU MCSim "mod" model generator
with the -R option. This should work under any operating system. You
can then use deSolve to perform simulations of your models. The
integators provided by deSolve are improved implementations of the
lsode family of integrators used by GNU MCSim. They provide a few more
options than GNU MCSim. However, if you need raw speed (say, for
Markov chain Monte Carlo simulations), then GNU MCSim is probably
still the fastest option.

If you are reading this file, you have probably already unzipped the
mcsim_under_R.zip archive. Unzipping creates a folder "MCSim under R".
In that folder are two sub-folders: "mod" and "my_R_project". You now have 
two options:

Option 1. This option is the simplest, but you will not have access to
          the latest "mod" version (because you are using code frozen in the
          archive) and you will not be able to run your model with the faster
          GNU MCSim code. You will have to use deSolve through a R script.
          
- Go to the "mod" folder. It contains a small config.h file. In that
  file there is really only one line that counts: the one defining
  whether you have libSBML installed. It is by default commented off:
  /* #define HAVE_LIBSBML 1 */ 
  If you have and want to use libSBML (recommended if you want to
  parse recent SBML models) you should uncomment that line.

- Then go to the "my_R_project" folder. It contains R scripts and 
  code to compile and build the "mod" (model generator) of GNU MCSim
  with the script "building_mod.R". That should be done first (and
  only once if you do not change the code of "mod" or update the
  libraries it uses.

- In the same folder, you can then run a simple differential equation 
  model written purely in R, for the R package deSolve (see the example
  "script_run_in_pure_R.R"). That does not require using GNU MCSim, but
  is as slow as R can be. A PDF figure of the expected results is
  included.

- Still in the "my_R_project" folder, the example R script
  "script_compile_run_with_deSolve.R" uses "mod" to compile and
  deSolve to run the same simple model, written in GNU MCSim format
  (file "simple.model"). A PDF figure of the expected results is
  included.


Option 2: This option let you use the latest code and run your models

          in GNU MCsim native code. For that, you should first
          download the distribution archive of GNU MCSim (like for a
          regular installation). Unpack it, but leave it as is. Just
          copy or move the "my_R_project" directory in that
          distribution directory, at the top level (same lavel as the
          "sim" and "mod" directories).

- In the MCSim distribution folder find and open the "config.h" file. It 
  defines options for compilation. Just check the following options:
  #define HAVE_LIBGSL 1
  #define HAVE_LIBGSLCBLAS 1
  #define HAVE_LIBSBML 1
  If you have installed the corresponding libraries (GNU GSL and its
  companion GSLcblas, and libSBML) then you should not change those
  defaults. It you have not installed some or all of those libraries
  a few options will not be available to you (in particular you will not
  be able to parse recent SBML models) and you should comment out the
  corresponding lines, as in:
  /* #define HAVE_LIBSBML 1 */ 
  and save the modified "config.h" file. 

- Then go to the "my_R_project" folder. It contains R scripts and 
  code to compile and build the "mod" (model generator) of GNU MCSim
  with the script "building_mod.R". That should be done first (and
  only once if you do not change the code of "mod" or update the
  libraries it uses.

- In the same folder, you can then run a simple differential equation 
  model written purely in R, for the R package deSolve (see the example
  "script_run_in_pure_R.R"). That does not require using GNU MCSim, but
  is as slow as R can be. A PDF figure of the expected results is
  included.

- Still in the "my_R_project" folder, the example R script
  "script_compile_run_with_deSolve.R" uses "mod" to compile and
  deSolve to run the same simple model, written in GNU MCSim format
  (file "simple.model"). A PDF figure of the expected results is
  included.

- Now the example R script "script_compile_run_with_MCSim.R" uses "mod" to
  compile and GNU MCSim to run the same simple model, written in GNU
  MCSim format (file "simple.model"). A simulation input file
  "simple.in" is provided together with the resulting test output file
  "sim.out" and a PDF figure of the expected results.


================
Technical Notes: 

- gcc optimization flag: in script_compile_run_with_MCSim.R the
  optimization flag is "-O3" (optimized code). You can indeed change
  that and introduce other options as you wish (see the gcc man pages
  for that).

