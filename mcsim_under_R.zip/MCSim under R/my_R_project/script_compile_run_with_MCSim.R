# Script for compiling and running (with MCSim) a model written in GNU MCSim
# The "mod.exe" utility must be available. If not, use the building_mod.R
# script to create it

# set the name of your model
mName = "simple.model"

# create a C file "mName".c from the
# GNU MCSim model definition file "mName"
# the R option generate deSolve compatible code
system(paste("../mod/mod.exe ", mName, " ", mName, ".c", sep = "")) 

# compile the MCSim executable, needs to be done each time you modify the model

# Your model executable can be linked with the GNU Scientific Library
# (GSL, recommended). If you have GSL installed the directives
# '#define HAVE_LIBGSL 1' and '#define HAVE_LIBGSLCBLAS 1' should
# appear in the config.h file, in the directory above this one. If it
# does not, put them in, alone at the beginning of a line.  If you do
# NOT have libGSL, those directives should NOT appear in that file. If
# they do, delete them.

libGSL = ""
# libGSL = "-lgsl -lgslcblas" # uncomment and execute if you have the GNU Scientific Library

system(paste("gcc -O3 -I.. -I../sim -o mcsim_", mName, ".exe ", mName, ".c ../sim/*.c -lm ", libGSL, sep = ""))

# run the simulation input file
# put its name here
simName = "simple.in"

# run!
system(paste("./mcsim_", mName, ".exe ", simName, sep = ""))

# the output file is called out by default, load it
out.m = read.delim("sim.out", skip = 2)

head (out.m)

# look
pdf("results_simple_pure_MCSim.pdf")

lo = layout(t(matrix(1:4, ncol = 2)), respect = TRUE)
plot(out.m[,1], out.m[,2], log="x",type="b", xlab = "time", ylab = "", main = "y1")
plot(out.m[,1], out.m[,3], log="x",type="b", xlab = "time", ylab = "", main = "y2")
plot(out.m[,1], out.m[,4], log="x",type="b", xlab = "time", ylab = "", main = "y3")

dev.off()

