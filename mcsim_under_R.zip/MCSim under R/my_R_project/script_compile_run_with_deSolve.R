# Script for compiling and running with deSolve a model written in GNU MCSim
# The "mod.exe" utility must be available. If not, use the building_mod.R
# script to create it

# set the name of your model
mName = "simple.model"

# create a C file "mName".c from the
# GNU MCSim model definition file "mName"
# the R option generate deSolve compatible code
system(paste("../mod/mod.exe -R ", mName, " ", mName, ".c", sep = "")) 

# compile the C model
system(paste("R CMD SHLIB ", mName, ".c", sep = ""))

# load the compiled model
dyn.load(paste(mName, .Platform$dynlib.ext, sep=""))

# load deSolve
library(deSolve)

# set parameters
parms = c(k1 = 0.04, k2 = 1e4, k3=3e7)

# set states
Y = c(y1 = 1.0, y2 = 0.0, y3 = 0.0)

# set output times
times = c(0, 0.4*10^(0:11))

# solve
out = ode(Y, times, func = "derivs", parms = parms,
          dllname = mName,
          initfunc = "initmod", nout = 1, outnames = "Sum")

head(out)

# look
plot(out,log="x",type="b")

pdf("results_simple_compiled_deSolve.pdf")
plot(out,type="b",log="x", which = c("y1", "y2", "y3"))
dev.off()

