# Script for building the "mod.exe" utility
# do it once (or do it if you delete "mod.exe" by mistake.
# The mod directory with all the needed C files should be in the current
# directory
# You may have to set gcc path explicitly

system("gcc -o mod.exe *.c")

# Test it, the following should run without errors and
# should create a C file simple_model.c from the
# GNU MCSim model definition file simple.model
# the R option generate deSolve compatible code
system("./mod.exe -R test/simple.model test/simple_model.c") 

# compile the C model
system("R CMD SHLIB test/simple_model.c")

# load the compiled model
dyn.load(paste("test/simple_model", .Platform$dynlib.ext, sep=""))

# load deSolve
library(deSolve)

# set parameters
parms = c(k1 = 0.04, k2 = 1e4, k3=3e7)

# set states
Y = c(y1 = 1.0, y2 = 0.0, y3 = 0.0)

# set output times
times = c(0, 0.4*10^(0:11))

# solve
out = ode(Y, times, func = "derivs", parms = parms,
          dllname = "simple_model",
          initfunc = "initmod", nout = 1, outnames = "Sum")

# look
plot(out,log="x",type="b")
