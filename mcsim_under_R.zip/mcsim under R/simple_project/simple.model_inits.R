initParms <- function(newParms = NULL) {
  parms <- c(
    k1 = 0.0,
    k2 = 0.0,
    k3 = 0.0
  )
  parms <- within(as.list(parms), {
    k1 = 1;
    k2 = 1;
    k3 = 1;
  })
  if (!is.null(newParms)) {
    if (!all(names(newParms) %in% c(names(parms)))) {
      stop("illegal parameter name")
    }
  }
  if (!is.null(newParms))
    parms[names(newParms)] <- newParms
  out <- .C("getParms",  as.double(parms),
            out=double(length(parms)),
            as.integer(length(parms)))$out
  names(out) <- names(parms)
  out
}

Outputs <- c(
    "yout"
)

initStates <- function(parms, newStates = NULL) {
  Y <- c(
    y0 = 0.0,
    y1 = 0.0,
    y2 = 0.0
  )
  if (!is.null(newStates)) {
    if (!all(names(newStates) %in% c(names(Y)))) {
      stop("illegal state variable name in newStates")
    }
    Y[names(newStates)] <- newStates
  }
  Y
}
