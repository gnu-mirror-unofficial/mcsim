==============================================
GNU MCSim and R (even under Microsoft Windows)
----------------------------------------------

The basic tools needed to build and run GNU MCSim are not available to
most users of Windows systems (arguably a poor and closed operating
system, whose usually incompetent administrators further lock against
installation of new tools under security pretexts, and/or are unable
to help). Fortunately, the R software (see http://www.r-project.org/),
when properly installed with its Rtools (this requires administrator's
right to do..., so ask a nice and competent administrator, there are
some) can compile and run GNU MCSim models. We have developed C code
and R scripts to compile GNU MCSim models to C code usable by the R
package deSolve (to do that use the GNU MCSim "mod" model generator
with the -R option) or by itself. This works under any operating
system. You can then use deSolve to perform simulations of your
models. The integators provided by deSolve are improved
implementations of the lsode family of integrators (used also by GNU
MCSim), and provide a few more options than GNU MCSim (in particular,
"events", see the deSolve user manuals). However, if you need raw
speed (say, for Markov chain Monte Carlo simulations) GNU MCSim is
the fastest option.

The unzipped directory we provide "my_project" is a template. To use
it you should first download the distribution code of GNU MCSim (like
for a regular installation). Unpack it, but leave it as is. Just place
the "my_project" directory in that distribution directory, at the top
level, same as the "sim" and "mod" directories. 

It  contains R scripts and code to:

- Compile and build the "mod" (model generator) of GNU MCSim (script
  building_mod.R). That should be done first (and only once if you do
  not change the code of "mod" or update the libraries it uses (see
  also the Technical Notes below).

- Run a simple differential equation model purely with R and the R
  package deSolve (script script_run_in_pure_R.R. That does not
  require using GNU MCSim, but is as slow as R can be. A PDF figure of
  the expected results is included.

- Compile and run the same simple model, written in GNU MCSim format
  (file "simple.model"), using deSolve (use script_compile_run_with_deSolve.R).
  A PDF figure of the expected results is included.

- Compile and run the same simple model in GNU MCSim format using only
  GNU MCSim, called from R (use script_compile_run_with_MCSim.R). A
  simulation input file "simple.in" is provided together with the
  resulting test output file "sim.out" and a PDF figure of the
  expected results.


================
Technical Notes: 

- gcc optimization flag: in script_compile_run_with_MCSim.R the
  optimization flag is "-O3" (optimized code). You can indeed change
  that and introduce other options as you wish (see the gcc man pages
  for that).

