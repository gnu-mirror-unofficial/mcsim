# Script for building the "mod.exe" utility.
# Run it once (or if you delete "mod.exe" by mistake).
# The mod directory with all the needed C files should be in the directory
# just above (or change the path accordingly).
# You may have to set gcc path explicitly too if Rtools are not well installed

# mod.exe can be linked with libSBML. This is recommended if you want
# to use SBML coded models.  If you have libSBML installed the
# directive '#define HAVE_LIBSBML 1' should appear in the config.h
# file, in the directory above this one. If it does not, put it in,
# alone at the beginning of a line.  If you do NOT have libSBML, the
# directive '#define HAVE_LIBSBML 1' should NOT appear in that
# file. If it does, delete it.

libSBML = ""
# libSBML = "-lsbml" # uncomment and execute if you have and want to use libSBML.

system(paste("gcc -o ../mod/mod.exe ../mod/*.c ", libSBML, sep = ""))

# check it works
system("../mod/mod.exe simple.model simple.model.c")

# you are done.
