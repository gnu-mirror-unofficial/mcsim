/* model.c for R deSolve package
   ___________________________________________________

   Model File:  pbpk.model

   Date:  Sun Feb 19 12:04:01 2012

   Created by:  "a.out v5.5.0"
    -- a model preprocessor by Don Maszle
   ___________________________________________________

   Copyright (c) 1993-2012 Free Software Foundation, Inc.

   Model calculations for compartmental model:

   6 States:
     Q_fat = 0.0,
     Q_wp = 0.0,
     Q_pp = 0.0,
     Q_liv = 0.0,
     Q_exh = 0.0,
     Q_met = 0.0,

   4 Outputs:
    "C_liv",
    "C_alv",
    "C_exh",
    "C_ven",

   2 Inputs:
     C_inh (forcing function)
     Q_ing (forcing function)

   18 Parameters:
     BodyWt = 70,
     PC_fat = 144,
     PC_liv = 4.6,
     PC_wp = 8.7,
     PC_pp = 1.4,
     PC_art = 12.0,
     V_fat = 10,
     V_liv = 2,
     V_wp = 45,
     V_pp = 5,
     Flow_fat = 0.5,
     Flow_liv = 1,
     Flow_wp = 2.5,
     Flow_pp = 1,
     Flow_tot = 5,
     Flow_alv = 6,
     Vmax = 0.01,
     Km = 1.0,
*/

#include <R.h>

/* Model variables: States */
#define ID_Q_fat 0x0000
#define ID_Q_wp 0x0001
#define ID_Q_pp 0x0002
#define ID_Q_liv 0x0003
#define ID_Q_exh 0x0004
#define ID_Q_met 0x0005

/* Model variables: Outputs */
#define ID_C_liv 0x0000
#define ID_C_alv 0x0001
#define ID_C_exh 0x0002
#define ID_C_ven 0x0003

/* Parameters */
static double parms[18];

#define BodyWt parms[0]
#define PC_fat parms[1]
#define PC_liv parms[2]
#define PC_wp parms[3]
#define PC_pp parms[4]
#define PC_art parms[5]
#define V_fat parms[6]
#define V_liv parms[7]
#define V_wp parms[8]
#define V_pp parms[9]
#define Flow_fat parms[10]
#define Flow_liv parms[11]
#define Flow_wp parms[12]
#define Flow_pp parms[13]
#define Flow_tot parms[14]
#define Flow_alv parms[15]
#define Vmax parms[16]
#define Km parms[17]

/* Forcing (Input) functions */
static double forc[2];

#define C_inh forc[0]
#define Q_ing forc[1]

/*----- Initializers */
void initmod (void (* odeparms)(int *, double *))
{
  int N=18;
  odeparms(&N, parms);
}

void initforc (void (* odeforcs)(int *, double *))
{
  int N=2;
  odeforcs(&N, forc);
}


/*----- Dynamics section */

void derivs (int *neq, double *pdTime, double *y, double *ydot, double *yout, int *ip)
{
  /* local */ double Cout_fat;
  /* local */ double Cout_wp;
  /* local */ double Cout_pp;
  /* local */ double Cout_liv;
  /* local */ double dQ_ven;
  /* local */ double C_art;
  /* local */ double dQmet_liv;

  Cout_fat = y[ID_Q_fat] / ( V_fat * PC_fat ) ;

  Cout_wp = y[ID_Q_wp] / ( V_wp * PC_wp ) ;

  Cout_pp = y[ID_Q_pp] / ( V_pp * PC_pp ) ;

  Cout_liv = y[ID_Q_liv] / ( V_liv * PC_liv ) ;

  dQ_ven = Flow_fat * Cout_fat + Flow_wp * Cout_wp + Flow_pp * Cout_pp + Flow_liv * Cout_liv ;

  yout[ID_C_ven] = dQ_ven / Flow_tot ;

  yout[ID_C_liv] = y[ID_Q_liv] / V_liv ;

  C_art = ( Flow_alv * C_inh + dQ_ven ) / ( Flow_tot + Flow_alv / PC_art ) ;

  yout[ID_C_alv] = C_art / PC_art ;

  yout[ID_C_exh] = 0.7 * yout[ID_C_alv] + 0.3 * C_inh ;

  dQmet_liv = Vmax * y[ID_Q_liv] / ( Km + y[ID_Q_liv] ) ;

  ydot[ID_Q_exh] = Flow_alv * yout[ID_C_alv] ;

  ydot[ID_Q_fat] = Flow_fat * ( C_art - Cout_fat ) ;

  ydot[ID_Q_wp] = Flow_wp * ( C_art - Cout_wp ) ;

  ydot[ID_Q_pp] = Flow_pp * ( C_art - Cout_pp ) ;

  ydot[ID_Q_liv] = Q_ing + Flow_liv * ( C_art - Cout_liv ) - dQmet_liv ;

  ydot[ID_Q_met] = dQmet_liv ;

} /* derivs */


/*----- Jacobian calculations: */
void jac (int *neq, double *t, double *y, int *ml, int *mu, double *pd, int *nrowpd, double *yout, int *ip)
{

} /* jac */


/*----- Events calculations: */
void event (int *n, double *t, double *y)
{

} /* event */

/*----- Roots calculations: */
void root (int *neq, double *t, double *y, int *ng, double *gout, double *out, int *ip)
{

} /* root */

