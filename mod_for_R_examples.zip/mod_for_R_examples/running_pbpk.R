system("R CMD SHLIB pbpk_model.c")

dyn.load("pbpk_model.so")

parms <- c(
     BodyWt = 70,
     PC_fat = 144,
     PC_liv = 4.6,
     PC_wp = 8.7,
     PC_pp = 1.4,
     PC_art = 12.0,
     V_fat = 10,
     V_liv = 2,
     V_wp = 45,
     V_pp = 5,
     Flow_fat = 0.5,
     Flow_liv = 1,
     Flow_wp = 2.5,
     Flow_pp = 1,
     Flow_tot = 5,
     Flow_alv = 6,
     Vmax = 0.01,
     Km = 1.0)

Y	<- c(
     Q_fat = 1.0,
     Q_wp  = 0.0,
     Q_pp  = 0.0,
     Q_liv = 0.0,
     Q_exh = 0.0,
     Q_met = 0.0)

times <- seq(0, 10020, 20)

Outputs <- c(
     "C_liv",
     "C_alv",
     "C_exh",
     "C_ven")
     
# integrate
out <- ode(Y, times, func = "derivs", parms = parms, jacfunc = "jac", dllname = "pbpk_model", initfunc = "initmod", nout = 4, outnames = Outputs, method="lsodes")

plot(out,log="y",type="l")


# with forcing

inh <- matrix(ncol=2,byrow=TRUE,data=c(0, 1, 299.9, 1, 240, 0, 20000, 0))
inh

ing <- matrix(ncol=2,byrow=TRUE,data=c(0, 0, 5000, 1, 5500, 0, 20000, 0))
ing

out <- ode(Y, times, func = "derivs", parms = parms, jacfunc = "jac", dllname = "pbpk_model", initforc = "initforc", forcings=list(inh,ing), initfunc = "initmod", nout = 4, outnames = Outputs, method="lsodes")

plot(out,log="y",type="l")

##### COOL. I should make sure that Inline in globals are put in globals, so that 
##### events and roots can be coded in the model

