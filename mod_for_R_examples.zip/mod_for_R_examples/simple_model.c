/* model.c for R deSolve package
   ___________________________________________________

   Model File:  simple.model

   Date:  Sun Feb 19 11:50:28 2012

   Created by:  "a.out v5.5.0"
    -- a model preprocessor by Don Maszle
   ___________________________________________________

   Copyright (c) 1993-2012 Free Software Foundation, Inc.

   Model calculations for compartmental model:

   3 States:
     y0 = 0.0,
     y1 = 0.0,
     y2 = 0.0,

   1 Output:
    "yout",

   0 Inputs:

   3 Parameters:
     k1 = 1,
     k2 = 1,
     k3 = 1,
*/

#include <R.h>

/* Model variables: States */
#define ID_y0 0x0000
#define ID_y1 0x0001
#define ID_y2 0x0002

/* Model variables: Outputs */
#define ID_yout 0x0000

/* Parameters */
static double parms[3];

#define k1 parms[0]
#define k2 parms[1]
#define k3 parms[2]

/* Forcing (Input) functions */
static double forc[0];


/*----- Initializers */
void initmod (void (* odeparms)(int *, double *))
{
  int N=3;
  odeparms(&N, parms);
}

void initforc (void (* odeforcs)(int *, double *))
{
  int N=0;
  odeforcs(&N, forc);
}


/*----- Dynamics section */

void derivs (int *neq, double *pdTime, double *y, double *ydot, double *yout, int *ip)
{

  ydot[ID_y0] = - k1 * y[ID_y0] + k2 * y[ID_y1] * y[ID_y2] ;

  ydot[ID_y2] = k3 * y[ID_y1] * y[ID_y1] ;

  ydot[ID_y1] = - ydot[ID_y0] - ydot[ID_y2] ;

  yout[ID_yout] = y[ID_y0] + y[ID_y1] + y[ID_y2] ;

} /* derivs */


/*----- Jacobian calculations: */
void jac (int *neq, double *t, double *y, int *ml, int *mu, double *pd, int *nrowpd, double *yout, int *ip)
{

} /* jac */


/*----- Events calculations: */
void event (int *n, double *t, double *y)
{

  y[ID_y0] = 1 ;

} /* event */

/*----- Roots calculations: */
void root (int *neq, double *t, double *y, int *ng, double *gout, double *out, int *ip)
{

 gout[0] = y[0] - 0.5; 

} /* root */

