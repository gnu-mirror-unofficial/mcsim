gcc -Ofast -I../sim -o mcsim_APAP ../sim/*.c model.c -lm -lgsl -lgslcblas -lsundials_cvodes -lsundials_nvecserial -llapack
