/* model.c
   ___________________________________________________

   Model File:  normal.model

   Date:  Sun Jul 22 15:32:01 2018

   Created by:  "mod v6.0.1"
    -- a model preprocessor by Don Maszle
   ___________________________________________________

   Copyright (c) 1993-2018 Free Software Foundation, Inc.

   Model calculations for compartmental model:

   0 States:

   1 Output:
     y -> 0.0;

   0 Inputs:

   2 Parameters:
     mu = 0;
     lambda = 0;
*/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <float.h>
#include "modelu.h"
#include "random.h"
#include "yourcode.h"


/*----- Indices to Global Variables */

/* Model variables: States and other outputs */
#define ID_y 0x00000

/* Inputs */

/* Parameters */
#define ID_mu 0x00001
#define ID_lambda 0x00002


/*----- Global Variables */

/* For export. Keep track of who we are. */
char szModelDescFilename[] = "normal.model";
char szModelSourceFilename[] = __FILE__;
char szModelGenAndVersion[] = "mod v6.0.1";

/* Externs */
extern BOOL vbModelReinitd;

/* Model Dimensions */
int vnStates = 0;
int vnOutputs = 1;
int vnModelVars = 1;
int vnInputs = 0;
int vnParms = 2;

/* States and Outputs*/
double vrgModelVars[1];

/* Inputs */
IFN vrgInputs[1];

/* Parameters */
double mu;
double lambda;

BOOL bDelays = 0;


/*----- Global Variable Map */

VMMAPSTRCT vrgvmGlo[] = {
  {"y", (PVOID) &vrgModelVars[ID_y], ID_OUTPUT | ID_y},
  {"mu", (PVOID) &mu, ID_PARM | ID_mu},
  {"lambda", (PVOID) &lambda, ID_PARM | ID_lambda},
  {"", NULL, 0} /* End flag */
};  /* vrgpvmGlo[] */


/*----- InitModel
   Should be called to initialize model variables at
   the beginning of experiment before reading
   variants from the simulation spec file.
*/

void InitModel(void)
{
  /* Initialize things in the order that they appear in
     model definition file so that dependencies are
     handled correctly. */

  vrgModelVars[ID_y] = 0.0;
  mu = 0;
  lambda = 0;

  vbModelReinitd = TRUE;

} /* InitModel */


/*----- Dynamics section */

void CalcDeriv (double  rgModelVars[], double  rgDerivs[], PDOUBLE pdTime)
{

  CalcInputs (pdTime); /* Get new input vals */


} /* CalcDeriv */


/*----- Model scaling */

void ScaleModel (PDOUBLE pdTime)
{

} /* ScaleModel */


/*----- Jacobian calculations */

void CalcJacob (PDOUBLE pdTime, double rgModelVars[],
                long column, double rgdJac[])
{

} /* CalcJacob */


/*----- Outputs calculations */

void CalcOutputs (double  rgModelVars[], double  rgDerivs[], PDOUBLE pdTime)
{

  rgModelVars[ID_y] = mu + NormalRandom ( 0 , lambda ) ;

}  /* CalcOutputs */


