y = rnorm(100, 0, 1)
writeLines(paste(format(y, digits=4)), sep=", ")
