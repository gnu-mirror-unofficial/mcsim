## testing script

## utility function to extract last perks from a perk output
get.final.perks = function (filename) {
  ncols = max(count.fields(filename, sep = "\t"))
  perks = read.delim(filename, col.names=1:ncols,
                     sep="\t", fill=T, header=F)
  ## dim(perks)
  ## head(perks, 10)
  ## lines are grouped by 5
  n.blocks = dim(perks)[1] / 5
  perks = perks[5 * (n.blocks - 1) + 1,-1]
  return(perks[which(perks <= 1)])
}

## utility function to extract all information from a perk output
get.all.perks = function (filename) {
  ncols = max(count.fields(filename, sep = "\t"))
  tmp = read.delim(filename, col.names=1:ncols,
                   sep="\t", fill=T, header=F)
  index = which(tmp[,1] == "Perks:")
  perks.table = as.matrix(tmp[index,-1])
  index = which(tmp[,1] == "Counts:")
  counts.table = as.matrix(tmp[index,-1])
  index = which(tmp[,1] == "LnPi(i):")
  lnpi.table = as.matrix(tmp[index,-1])
  index = which(tmp[,1] == "Tried Jumps:")
  try.table = as.matrix(tmp[index,-1])
  index = which(tmp[,1] == "Accepted Jumps:")
  accept.table = as.matrix(tmp[index,-1])
  return(list("perks"  = perks.table,
              "counts" = counts.table,
              "lnpi"   = lnpi.table,
              "trials" = try.table,
              "accept" = accept.table))
}

## function plotting the evolution of the temperature scale when adjusting it
plot.all.perks = function (all.perks, mylog="x") {
  par(mar=c(5, 5, 1, 1))
  N.iters = dim(all.perks$perks)[1]
  xlims  = c(1E-7,1)
  ylims  = range(all.perks$lnpi, na.rm=T)
  mycols = rainbow(N.iters)
  for (i in 1:N.iters) {
    j = which(!is.na(all.perks$perks[i,]))
    if (i == 1) {
      plot(all.perks$perks[i,j], all.perks$lnpi[i,j], type="b", las=1,
           log=mylog, xlab="Perk", ylab="", cex.lab=1.4,
           xlim=xlims, ylim=ylims, col=mycols[i], lwd=2)
      mtext("Log pseudo-prior", side=2, line=3.6, cex=1.4)      
    } else {
      plot(all.perks$perks[i,j], all.perks$lnpi[i,j], type="b", las=1,
           log=mylog,
           xlim=xlims, ylim=ylims, xaxt="n", yaxt="n", xlab="", ylab="",
           col=mycols[i], lwd=2)
    }
    par(new=T)
  }
  par(new=F)
}

## plot the evolution of the slopes of the temperature scale
plot.all.perks.slopes = function (all.perks, mylog="xy") {
  par(mar=c(5, 5, 1, 1))
  N.iters = dim(all.perks$perks)[1]
  xlims  = c(1E-7,1)
  ylims  = c(1,1E7)
  mycols = rainbow(N.iters)
  for (i in 1:N.iters) {
    j = which(!is.na(all.perks$perks[i,]))
    n.perks = length(j)
    slopes = rep(0, n.perks)
    k = 1
    slopes[k] = (all.perks$lnpi[i,k+1]  - all.perks$lnpi[i,k]) /
                (all.perks$perks[i,k+1] - all.perks$perks[i,k])
    if (n.perks > 2)
     for (k in 2:(n.perks-1)) {
      slopes[k] = ((all.perks$lnpi[i,k+1]  - all.perks$lnpi[i,k]) /
                   (all.perks$perks[i,k+1] - all.perks$perks[i,k]) +
                   (all.perks$lnpi[i,k]  - all.perks$lnpi[i,k-1]) /
                   (all.perks$perks[i,k] - all.perks$perks[i,k-1])) * 0.5
    }
    k = n.perks
    slopes[k] = (all.perks$lnpi[i,k]  - all.perks$lnpi[i,k-1]) /
                (all.perks$perks[i,k] - all.perks$perks[i,k-1])
    if (i == 1) {
      plot(all.perks$perks[i,j], slopes, type="b", las=1, log=mylog,
           xlab="Perk", ylab="", cex.lab=1.4,
           xlim=xlims, ylim=ylims, col=mycols[i])
      mtext("Log pseudo-prior slope", side=2, line=3.8, cex=1.4)
    }
    else
      plot(all.perks$perks[i,j], slopes, type="b", las=1, log=mylog,
           xlim=xlims, ylim=ylims, xaxt="n", yaxt="n", xlab="", ylab="",
           col=mycols[i])    
    par(new=T)
  }
  par(new=F)
} # end plot.all.perks.slopes()

## function to plot the temperatures visits
plot.perks.visits = function(mcmc, n_temper) {
  par(mar=c(5, 5, 1, 1))
  plot(mcmc$iter, mcmc$IndexT, type='l', ylim=c(0,n_temper-1), las=1,
       xlab="Iteration", ylab="Perk index", cex.lab=1.5)
}

## function to plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro = function (mcmc, n_temper, nrows=7, ncols=7) {
  ## array indices for the pseudos priors
  i_start_pseudos = pmatch("LnPseudoPrior.1.",names(mcmc))
  i_end_pseudos = i_start_pseudos + n_temper - 1
  irange.top = i_start_pseudos:i_end_pseudos
  par(mfrow=c(nrows,ncols), mar=c(3,3,1,1))
  for (i in (irange.top)) {
    plot(mcmc$iter, mcmc[,i], type='l', las=1) 
  }
}

## function to plot linear2 posterior in 2D
plot.lin2.2D = function(mcmc) {
  plot(mcmc$SD_z, mcmc$B.1., pch=".", las=1, xlab="SD_z", ylab="B")
}

## function to plot linear2 posterior in 3D
plot.lin2.3D = function(mcmc) {
  library(rgl)
  plot3d(x=mcmc$SD_y, y=mcmc$SD_z, z=mcmc$B.1., type="s", size=0.25,
        xlab="SD_y", ylab="SD_z", zlab="B", col="red")
}

## function to plot linear3 posterior in 2D
plot.lin3 = function(mcmc, n_temper) {
  par(mar=c(5,5,1,1))
  xlims = c(-5,10)
  ylims = c(-5,20)
  mycolors=rainbow(n_temper)
  for (j in 1:(n_temper-1)) {
    i = which(mcmc$IndexT == (j-1))
    plot(mcmc$Slo[i], mcmc$Inter[i], pch=".",
         xlab="", ylab="", xaxt="n", yaxt="n",
         xlim=xlims, ylim=ylims, col=mycolors[j])
    par(new=T)
  }
  par(new=T)
  i = which(mcmc$IndexT == n_temper-1)
  plot(mcmc$Slo[i], mcmc$Inter[i], pch=".",
       las=1, xlab="Slope", ylab="Intersect", 
       xlim=xlims, ylim=ylims, col ="black", cex.lab=1.2)
  par(new=F)
}

## function to plot 1cpt parameter trajectories
plot.1cpt.trajectories = function (mcmc, n_temper) {
  par(mfrow=c(3,1), mar=c(4,4,1.5,1))
  noms = c("Ka", "Ke", "F")
  mycol = rev(rainbow(n_temper))
  for (i in 2:4) {
   ylims = range(mcmc[,i])
   labelled = F 
   for (j in 0:(n_temper-1)) {
     index = which(mcmc$IndexT==j)
     if (length(index) != 0) {
       if (!labelled) {
         plot(mcmc$iter[index], mcmc[index,i], type='l', log = "y", las = 1,
           xlab = ifelse(i == 4,"Iteration",""), ylab = "", col = mycol[j+1],
           xaxt = ifelse(i == 4,"s","n"), ylim = ylims, main = noms[i-1])
         labelled = T
       } else {
         plot(mcmc$iter[index], mcmc[index,i], type='l', log = "y",
              xaxt = "n", yaxt = "n", xlab = "", ylab = "", col = mycol[j+1],
              ylim = ylims)
       }
       par(new=T)
     }
   }
   par(new = F)
  }
}

## function to plot posterior histograms for a parameter at a time
plot.post.histograms = function (mcmc, n_temper, parm=1, a=6, b=5) {
  par(mfrow=c(a,b), mar=c(4,4,1.5,1))
  i = parm+1
  xlims = range(mcmc[,i])
  for (j in 0:(n_temper-1)) {
    index = which(mcmc$IndexT==j)
    hist(mcmc[index,i], main=perks[j+1], xlab="", ylab="", xlim=xlims, axes=F,
         breaks=20)
    ##text(min(xlims), length(index)/4, paste0("N=",length(mcmc[index,i])),
    ##     cex=0.7)
    axis(1)
  }
}

## function to compute effective sample sizes
compute_neff = function(mcmc, n_temper, index_parms) {
  ## index_parms is a vector of column numbers (parameters) for which n_eff
  ## should be calculated
  library(rstan)
  index  = which(mcmc$IndexT == n_temper-1)
  n.samples = length(index)
  n.chains  = 1
  n.parms   = length(index_parms)
  sims = array(0, c(n.samples, n.chains, n.parms))
  sims[,1,] = as.matrix(mcmc[index, index_parms])
  mysummary = monitor(sims, warmup=0, probs=NA, digit=4)
  return(c(mysummary[1,"n_eff"], n.samples))
}

## set base directory
base.dir = getwd()
system("rm ./sim/model.c") # avoid conflict, model.c file must be prepared


## ==============================================
## normal model (inference about a Gaussian mean)

setwd(base.dir)
setwd("normal")

system("sh script_compile_fast.sh")

## --------------------
## likelihood tempering

## system("time ./mcsim_norm normal.LTMCMC.in")

## get all perks
all.perks = get.all.perks("normal.LTMCMC.out.perks")

## plot the evolution of the temperature scale
pdf("Mean perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## plot the evolution of the slopes of the temperature scale
plot.all.perks.slopes(all.perks, mylog="y")

## read tempered mcmc output
mcmc = read.delim("normal.LTMCMC.out")

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

perks = get.final.perks("normal.LTMCMC.out.perks")
n_temper = length(perks)

## plot last perks and pseudo-priors
par(mar=c(5, 5, 2, 1))
lnpseudos = as.numeric(all.perks$lnpi[dim(all.perks$lnpi)[1],])
lnpseudos = lnpseudos - min(lnpseudos, na.rm=T) + 1
lnpseudos = lnpseudos[1:which(perks==1)]
plot(as.numeric(perks), lnpseudos, las=1,
     xlab="Perks", ylab="Log pseudo-prior", cex.lab=1.4,
     type="b", lwd=2, xlim=c(1E-7,1), log="xy")

## plot the temperatures visits
## pdf("Temperature visits.pdf")
plot.perks.visits(mcmc[90001:100000,], n_temper)
## dev.off()

table(mcmc$IndexT) # the record in the xxx.out.perks file is better:
dim(all.perks$counts)
occupancies = all.perks$counts[dim(all.perks$counts)[[1]],]

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, nrows=3, ncols=3)

## trajectory at target temperature
dev.new()
index0 = which(mcmc$IndexT == 0)
index  = which(mcmc$IndexT == n_temper-1)
## remove values found before hiting perk zero for the first time (useless)
index  = index[index > min(index0)] 
plot(mcmc$mu[index], type="l", col ="black", las=1, xlab="A", ylab="B")
mean(mcmc$mu[index])
sd(mcmc$mu[index])

## The analytical solution is (given that the prior on mu was 0, with precision
## 1/100 and there are 100 data points (from Bernardo and Smith)
lambda.0 = 0.01 # prior
SD.0 = sqrt(1/lambda.0)
n = 100
lambda.true = 1
lambda.n = lambda.0 + n * lambda.true
SD.n = sqrt(1/lambda.n)
SD.n

mu.0 = 0 # prior
xbar = -0.0631515  # data mean 
mu.n = (lambda.0 * mu.0 + n * lambda.true * xbar) / lambda.n
mu.n

## test of MCSim lnDFNormal function
lnDFNormal = function (x, mu, sd) {
  return( -0.918938533204672669541 - log (sd) - 0.5 * ((mu - x)/sd)^2)
}
lnDFNormal(-30, mu.0, SD.0)
dnorm(-30, mu.0, SD.0, log=T)
## OK, exact

## plot exact prior and posterior
pdf("Exact prior and posterior.pdf")
par(mfrow=c(2,1))
xlims = c(-50, 50)
x = seq(xlims[1], xlims[2], 0.01)
y.0 = dnorm(x, mu.0, SD.0, log=F)
plot(x, y.0, xlim=xlims, type="l", main="Prior",
     xlab="", ylab="", las=1, yaxt="s", lwd=2,  col="red")
par(new=F)
y.n = dnorm(x, mu.n, SD.n, log=F)
plot(x, y.n, xlim=xlims, type="l", main="Posterior",
     xlab="", ylab="", las=1, yaxt="s", lwd=2,  col="red")
dev.off()

area.0 = sum(0.01 * y.0)
area.0
area.n = sum(0.01 * y.n)
area.n

## plot exact and sampled prior
pdf("Exact and sampled prior.pdf")
par(mfrow=c(2,1), mar=c(4,5,1,1))
xlims = c(-50, 50)
index0 = which(mcmc$IndexT == 0)
index  = which(mcmc$IndexT == n_temper-1)
## remove values found before hiting perk zero for the first time
index  = index[index > min(index0)] 
## top panel: the MCMC sample and true density
hist(mcmc$mu[index0], xlim=xlims, xlab=expression(mu), ylab="",
     main = "", yaxt="n", cex.lab=1.5)
par(new=T)
x = seq(xlims[1], xlims[2], 0.01)
plot(x, dnorm(x, mu.0, SD.0, log=F), xlim=xlims, type="l",
     xlab="", ylab="", xaxt="n",
     yaxt="n", lwd=2,  col="red")
## bottom panel: the densities
ylims=c(-18, -2)
plot(mcmc$mu[index0], mcmc$LnPrior[index0], xlim=xlims, ylim=ylims, pch="+", 
     xlab=expression(mu), ylab="Log-density", las=1, cex.lab=1.5)
par(new=T)
plot(x, dnorm(x, mu.0, SD.0, log=T), xlim=xlims, ylim=ylims, type="l",
     xlab="", ylab="",
     xaxt="n", yaxt="n", lwd=2,  col="red")
dev.off()

## get Pdata, at last!
pseudo.prior = tail(mcmc[grep("LnPseudoPrior.",names(mcmc))], 1)
lnPdata = as.numeric(pseudo.prior[1] - pseudo.prior[n_temper])
## taking occupancy into account:
LnPdata = lnPdata + log(occupancies[n_temper]) - log(occupancies[1])

## plot exact and sampled posterior
pdf("Exact and sampled posterior.pdf")
par(mfrow=c(2,1), mar=c(4,5,1,1))
xlims = c(-0.5, 0.4)
index0 = which(mcmc$IndexT == 0)
index  = which(mcmc$IndexT == n_temper-1)
## remove values found before hiting perk zero for the first time
index  = index[index > min(index0)]
## top panel: the MCMC sample and true density
hist(mcmc$mu[index], xlim=xlims, xlab=expression(mu), ylab="",
     main = "", yaxt="n", cex.lab=1.5)
par(new=T)
x = seq(xlims[1], xlims[2], 0.01)
plot(x, dnorm(x, mu.n, SD.n, log=F), xlim=xlims, type="l",
     xlab="", ylab="", xaxt="n",
     yaxt="n", lwd=2,  col="red")
## bottom panel: the densities
ylims=c(-10, 5)
plot(mcmc$mu[index], mcmc$LnPosterior[index] - lnPdata, xlim=xlims, ylim=ylims,
     pch="+", cex.lab=1.5, 
     xlab=expression(mu), ylab="Log density", las=1)
par(new=T)
plot(x, dnorm(x, mu.n, SD.n, log=T), xlim=xlims, ylim=ylims, type="l",
     xlab="", ylab="",
     xaxt="n", yaxt="n", lwd=2,  col="red")
legend(-0.52, 5, legend=c("Exact density", "MCMC normalized"), lty=c(1,0),
       pch=c(NA,"+"),
       lwd=2, col=c("red","black"))
dev.off()

pdf("Matching posterior densities")
plot(dnorm(mcmc$mu[index], mu.n, SD.n, log=T),
     mcmc$LnPosterior[index] + lnPdata, 
     las=1, col="red", xlab="Exact posterior density",
     ylab = "LTMCMC estimated posterior density", cex.lab=1.3)
dev.off()

## computed effective number of samples at target
compute_neff(mcmc, n_temper, 2)
## 10805 effective over 12634 actual


## ====================
## linear2 bimodal model

setwd(base.dir)
setwd("linear2")

system("sh script_compile_fast.sh")

## --------------------
## likelihood tempering

## system("time ./mcsim_lin2 linear2.LTMCMC.in")

## get all perks
all.perks = get.all.perks("linear2.LTMCMC.out.perks")

## plot the evolution of the temperature scale
pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## plot the evolution of the slopes of the temperature scale
plot.all.perks.slopes(all.perks, mylog="y")

## read tempered mcmc output
mcmc = read.delim("linear2.LTMCMC.out")

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

perks = get.final.perks("linear2.LTMCMC.out.perks")
n_temper = length(perks)
n_temper

## plot last perks and pseudo-priors
par(mar=c(5, 5, 2, 1))
lnpseudos = as.numeric(all.perks$lnpi[dim(all.perks$lnpi)[1],])
lnpseudos = lnpseudos - min(lnpseudos, na.rm=T) + 1
lnpseudos = lnpseudos[1:which(perks==1)]
plot(as.numeric(perks), lnpseudos, las=1,
     xlab="Perks", ylab="Log pseudo-prior", cex.lab=1.4,
     type="b", lwd=2, xlim=c(1E-7,1), log="xy")

## plot the temperatures visits
pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
dev.off()
table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, 3, 5)

## plot the data (remember, for the model y = z)
pdf("Data and predictions.pdf")
par(mar=c(5, 5, 7, 7), xpd=F)
x = seq(1, 10, 1);
y = c(-1.006879, -2.001636, -2.993538, -3.994545, -5.008485, -6.006281,
      -6.977793, -8.004303, -8.999835, -9.992217);
z = c(+1.006879, +2.001636, +2.993538, +3.994545, +5.008485, +6.006281,
      +6.977793, +8.004303, +8.999835, +9.992217);
## dev.new()
xlims = c(0, 10)
ylims = range(c(y, z))
plot(x, y, xlim=xlims, ylim=ylims, type="n", pch=16, col="red", las=1,
     cex.lab=1.5, bty="n")
## abline(a=0, b=1) # true line, but it's obvious
## add some random simulations at target
## mycols = rev(rainbow(n_temper))
mycols = rev(heat.colors(n_temper))
for (j in 1:n_temper) {
  index = which(mcmc$IndexT == j - 1)
  for (i in 1:20) {
   abline(0, mcmc$B.1.[sample(index, 1)], col=mycols[j])
  }
}
points(x, y, pch=16)
points(x, z, pch=16)
box()
par(xpd=T)
legend("topright", inset=c(-0.27,0), legend=perks, lty=1, col=mycols,
       title="Perks")
dev.off()

## plot linear2 posterior in 2D
dev.new()
plot.lin2.2D(mcmc)

## plot linear2 posterior in 3D
## plot.lin2.3D(mcmc)
library(rgl)
open3d()
par3d(windowRect=c(20, 60, 770, 810))
## good.par = par3d()
## good.par$userMatrix
my.userMatrix = matrix(
  c( 0.7632413, -0.6460999, 0.004215047,    0,
     0.1214922,  0.1499206, 0.981205046,    0,
    -0.6345884, -0.7483841, 0.192921668,    0,
     0.0000000,  0.0000000, 0.000000000,    1), byrow=T, 4, 4)
view3d(fov=30, interactive=F, userMatrix=my.userMatrix)
index = which(mcmc$IndexT == n_temper - 1)
plot3d(x=mcmc$SD_y[index], y=mcmc$SD_z[index], z=mcmc$B.1.[index],
       type="s", size=0.25, zlim=c(-2.3,2.3),
       xlab="", ylab="", zlab="", col="red")
## set to True if you do not want the next commands would change the plot size
par3d(ignoreExtent=T) 
## add text, such as axes labels
text3d(x=+15, y=-7,  z=-2.5, "SD2", family="sans", cex=1.5, col="black")
text3d(x=-12, y=+15, z=-2.5, "SD1", family="sans", cex=1.5, col="black")
text3d(x=-6,  y=30,  z=1.7, "Slope",    family="sans", cex=1.5, col="black")
rgl.snapshot("Joint posterior sample at target - 3D.png", fmt = "png", top =F)

## Show posterior histograms for a parameter at a time
pdf("Posterior histograms slope.pdf")
plot.post.histograms(mcmc, n_temper, parm=1, 3, 4)
dev.off()
pdf("Posterior histograms SDy.pdf")
plot.post.histograms(mcmc, n_temper, parm=2, 3, 4)
dev.off()
pdf("Posterior histograms SDz.pdf")
plot.post.histograms(mcmc, n_temper, parm=3, 3, 4)
dev.off()

## an histogram for the slope at target
index = which(mcmc$IndexT == n_temper - 1)
hist(mcmc$B.1.[index], breaks=2000, xlim=c(-1.5,1.5))

## nice plot of the posterior versus B values
pdf("Slope posterior smooth.pdf")
i2 = order(mcmc$B.1.[index])
x = (mcmc$B.1.[index])[i2]
y = exp((mcmc$LnPosterior[index])[i2])
par(mfrow=c(1,2))
## first panel
par(mar=c(4, 2, 2, 0))
xlims = c(-1.015, -0.985)
## plot(x, y, type="p", bty="n", yaxt="n",
##      pch=16, xlim=xlims, xlab="Slope", cex=0.25, ylab="")
## par(new=T)
m1 = mean(x[x > xlims[1] & x < xlims[2]])
s1 = sd(x[x > xlims[1] & x < xlims[2]])
x2 = seq(xlims[1], xlims[2], (xlims[2] - xlims[1])/300)
plot(x2, dnorm(x2, m1, s1), xlim=xlims, type="l", xaxt="n", yaxt="n",
     xlab="", ylab="", bty="n", col="red", lwd=2)
axis(1, at=c(xlims[1], -1.01, -1, -0.99, xlims[2]),
     labels=c("", "-1.01", "-1", "-0.99", ""), line=0.2)
mtext("...", side=1, at=c(-0.9828, 0))
mtext("Slope", side=1, line=2.5, at=-0.9828, cex=2)
par(xpd=NA)
lines(c(-0.9835, -0.9825), c(-10, 10)) # break marks
lines(c(-0.9825, -0.9815), c(-10, 10)) # break marks
par(xpd=F)
## second panel
par(mar=c(4, 1, 2, 2))
xlims = rev(-c(-1.015, -0.985))
## plot(x, y, type="p", bty="n", yaxt="n",
##      pch=16, xlim=xlims, xlab="Slope", cex=0.25, ylab="")
## par(new=T)
m1 = mean(x[x > xlims[1] & x < xlims[2]])
s1 = sd(x[x > xlims[1] & x < xlims[2]])
x2 = seq(xlims[1], xlims[2], (xlims[2] - xlims[1])/300)
plot(x2, dnorm(x2, m1, s1), xlim=xlims, type="l", xaxt="n", yaxt="n",
     xlab="", ylab="", bty="n", col="red", lwd=2)
axis(1, at=c(xlims[1], rev(-c(-1.01, -1, -0.99)), xlims[2]),
     labels=c("", "0.99", "1", "1.01", ""), line=0.2)
dev.off()

## alternative nice plot of the posterior versus B values
pdf("Slope posterior sample.pdf")
i2 = order(mcmc$B.1.[index])
x = (mcmc$B.1.[index])[i2]
y = exp((mcmc$LnPosterior[index])[i2])
par(mfrow=c(1,2))
## first panel
par(mar=c(4, 2, 2, 0))
xlims = c(-1.015, -0.985)
plot(x, y, type="p", bty="n", xaxt="n", yaxt="n",
     pch=16, xlim=xlims, xlab="", cex=0.3, ylab="")
axis(1, at=c(xlims[1], -1.01, -1, -0.99, xlims[2]),
     labels=c("", "-1.01", "-1", "-0.99", ""), line=0.2)
mtext("...", side=1, at=c(-0.9828, 0))
mtext("Slope", side=1, line=2.5, at=-0.9828, cex=2)
## second panel
par(mar=c(4, 1, 2, 2))
xlims = rev(-c(-1.015, -0.985))
plot(x, y, type="p", bty="n", xaxt="n", yaxt="n",
     pch=16, xlim=xlims, xlab="", cex=0.3, ylab="")
axis(1, at=c(xlims[1], rev(-c(-1.01, -1, -0.99)), xlims[2]),
     labels=c("", "0.99", "1", "1.01", ""), line=0.2)
dev.off()

## plot trajectory
plot(mcmc$B.1.[index], type="l", pch=".")
plot(mcmc$B.1.[index], type="p", pch=".")

## computed effective number of samples at target
compute_neff(mcmc, n_temper, 2:4)

## miscellaneous calculations

## volume of the prior parameter space:
V = 20 * (100 - 0.001)^2
## = 199996
## volume of the prior parameter space show on Figure 4 of the paper:
Vf = 5 * 30 * 30
## = 4500
## Vf is 100 * Vf / V = 2.25% of V  
## approximate volume of the envelope of the posterior parameter sample
## (two cones of base diameter 3E-3 and height 25)
v = 2 * (3E-3 / 2)^2 * 25 * pi / 3
## = 0.000118
## v is 100 * v / V = 6E-8% of V

## distance between the two peaks for slope
pnorm(2, 0, 1E-3, log.p=T)


## ===============
## APAP model

## --------------------
## likelihood tempering

setwd(base.dir)
setwd("APAP")

system("sh script_compile_fast.sh")

## system("time ./mcsim_APAP APAP.LTMCMC.in")

## get all perks
all.perks = get.all.perks("APAP.LTMCMC.out.perks")

## plot the evolution of the temperature scale
## pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
## dev.off()

## plot the evolution of the slopes of the temperature scale
plot.all.perks.slopes(all.perks, mylog="y")

## read tempered mcmc output
mcmc = read.delim("APAP.LTMCMC.out")
dim(mcmc)

## perk 0.1 reached in about 1.5 hours
## perk zero reached in 62200 iterations
## total time for warmup + 1000 iterations: 6:15 hours

perks = get.final.perks("APAP.LTMCMC.out.perks")
n_temper = length(perks)

## plot last perks and pseudo-priors
par(mar=c(5, 5, 2, 1))
lnpseudos = as.numeric(all.perks$lnpi[dim(all.perks$lnpi)[1],])
lnpseudos = lnpseudos - min(lnpseudos, na.rm=T) + 1
lnpseudos = lnpseudos[1:which(perks==1)]
plot(as.numeric(perks), lnpseudos, las=1,
     xlab="Perks", ylab="Log pseudo-prior", cex.lab=1.4,
     type="b", lwd=2, xlim=c(1E-7,1), log="xy")

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
## pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
## dev.off()
table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper)

## Show posterior histograms for a parameter at a time
plot.post.histograms(mcmc, n_temper, parm=1)

## restart the chain
## system("time ./mcsim_APAP APAP.LTMCMC.2.in")

## read tempered mcmc output
mcmc = read.delim("APAP.LTMCMC.2.out")
dim(mcmc)

## 1E5 iterations took 11:15 h

perks = get.final.perks("APAP.LTMCMC.out.perks")
n_temper = length(perks)

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
## pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
## dev.off()
table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper)

## Show posterior histograms for a parameter at a time
dev.new()
plot.post.histograms(mcmc, n_temper, parm=2)

## some stats
index = which(mcmc$IndexT==n_temper-1)
means = apply(mcmc[index,-1], 2, mean)
SDs   = apply(mcmc[index,-1], 2, sd)

## TI posterior distributions boxplots
pdf("APAP LTMCMC population.pdf")
boxplot(mcmc[index,2:44], las=1, log="", outline=F, xaxt="n", main="")
text(1, 14.5, "A", cex=2)
axis(1, at=c(0.60,20.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(mu)), side=1, line=2, at=10.5, cex=1.7)
axis(1, at=c(20.6,40.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(Sigma^2)), side=1, line=2, at=30.5, cex=1.6)
axis(1, at=c(40.6,43.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(sigma^2)), side=1, line=2, at=42, cex=1.6)
dev.off()

pdf("APAP LTMCMC individuals.pdf")
boxplot(mcmc[index,45:(dim(mcmc)[2] - 4 - n_temper)],
        las=1, log="", outline=F, xaxt="n", main="")
text(1, 14.5, "A", cex=2)
for (i in 1:8) {
  fro =  1 + (i-1) * 20
  to  = 20 + (i-1) * 20
  axis(1, at=c(fro, to), lab=c("",""), line=1, tcl=0.0)
  mtext(paste0("S",i), side=1, line=2, at=fro+10, cex=1.5)
}
dev.off()

## get the MPV
max(mcmc$LnPost[index])
index.mpv = which(mcmc$LnPost[index] == max(mcmc$LnPost[index]))
mcmc[index[index.mpv],]

## save the target sample
write.table(mcmc[index,], "APAP.LTMCMC.at_target.dat", quote=F, row.names=F)

## write 20 random vectors and MPV at target
write.table(mcmc[sample(index, 20),], "APAP.LTMCMC_20+MPV.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc[index[index.mpv],], "APAP.LTMCMC_20+MPV.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## read fit check results
fit = read.delim("APAP.fit_LTMCMC.out")
plot(fit$Pred, fit$Data, las=1)
abline(0,1)
.

## ------------------------------
## reference runs (straight MCMC)
## 10 chains of 3E5 simulations each. Each
## took between 26 and 34 hours (average 33 h).

conv = read.delim("convanal_check_half.out", skip=1)

i = 1:203
par(las=1)
plot(conv$Average[i], means[i], xlab="MCMC average", ylab="LTMCMC average")
abline(0,1)
plot(conv$SD[i], SDs[i], xlab="MCMC SD", ylab="LTMCMC SD")
abline(0,1)

## read reference mcmc final sample
mcmc.ref = read.delim("apap20d.final.dat")
dim(mcmc.ref)

## reference posterior distributions boxplots
pdf("APAP reference population.pdf")
boxplot(mcmc.ref[,2:44], xaxt="n",
        las=1, log="", outline=F, main="")
text(1, 14.5, "B", cex=2)
axis(1, at=c(0.60,20.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(mu)), side=1, line=2, at=10.5, cex=1.7)
axis(1, at=c(20.6,40.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(Sigma^2)), side=1, line=2, at=30.5, cex=1.6)
axis(1, at=c(40.6,43.4), lab=c("",""), line=1, tcl=0.5)
mtext(expression(bold(sigma^2)), side=1, line=2, at=42, cex=1.6)
dev.off()

pdf("APAP reference individuals.pdf")
boxplot(mcmc.ref[,45:(dim(mcmc.ref)[2] - 3)],
        las=1, log="", outline=F, xaxt="n", main="")
text(1, 14.5, "B", cex=2)
for (i in 1:8) {
  fro =  1 + (i-1) * 20
  to  = 20 + (i-1) * 20
  axis(1, at=c(fro, to), lab=c("",""), line=1, tcl=0.0)
  mtext(paste0("S",i), side=1, line=2, at=fro+10, cex=1.5)
}
dev.off()

## get the MPV
max(mcmc.ref$LnPost)
index.ref.mpv = which(mcmc.ref$LnPost == max(mcmc.ref$LnPost))
mcmc.ref[index.ref.mpv,]

## write 20 random vectors and MPV at target
write.table(mcmc.ref[sample((1:dim(mcmc.ref)[1]), 20),],
            "APAP.ref_20+MPV.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc.ref[index.ref.mpv,], "APAP.ref_20+MPV.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## plot
pdf("APAP MPV fits.pdf")
par(mar=c(5,5,1,1))
xlims = ylims = range(c(exp(fit$Data), exp(fit$Pred), exp(fit.ref$Pred)))/1000
fit.ref = read.delim("APAP.fit_ref.out")
plot(exp(fit.ref$Pred)/1000, exp(fit.ref$Data)/1000, las=1, log="xy",
     xlim=xlims, ylim=ylims, pch=20,
     xlab=expression("Predicted concentration ("*mu*"g/mL)"),
     ylab=expression("Observed concentration ("*mu*"g/mL)"),
     cex.lab=1.3)
par(new=T)
plot(exp(fit$Pred)/1000, exp(fit$Data)/1000,
     las=1, xlim=xlims, ylim=ylims, col="red",
     xlab="", ylab="", xaxt="n", yaxt="n", log="xy")
abline(0,1)
legend(0.4, 100, c("MCMC", "IT MCMC"), pch=c(20, 1), col=c("black", "red"))
dev.off()

## some additional comparisons of fits:
mean(fit$Data - fit$Pred)
mean(fit.ref$Data - fit.ref$Pred)

sd(fit$Data - fit$Pred)
sd(fit.ref$Data - fit.ref$Pred)


## =================================================================
## Theophylline with two-cpt model inter-individual variability only

## --------------------
## likelihood tempering

setwd(base.dir)
setwd("theophylline/IT runs inter")

## system("sh script_compile_fast.sh")
## system("time ./mcsim_theoph theoph.LTMCMC.inter.in")
## Perk 0 reached in 20400 iterations (31 minutes)
## Total time Markov: 56 min on workstation

## get all perks
all.perks = get.all.perks("theoph.LTMCMC.inter.out.perks")

## plot the evolution of the temperature scale
pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## read tempered mcmc output
mcmc = read.delim("theoph.LTMCMC.inter.out")
dim(mcmc)

## read the reference mcmc output
mcmc.ref = read.delim("../Reference runs inter/theoph.final.dat")

perks = get.final.perks("theoph.LTMCMC.inter.out.perks")
n_temper = length(perks)

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
dev.off()

table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, 4, 5)

## Show posterior histograms for a parameter at a time
plot.post.histograms(mcmc, n_temper, parm=7)

## some stats
## TI runs
index = which(mcmc$IndexT==n_temper-1)
removed = c(1, (dim(mcmc)[[2]] - 3 - n_temper):dim(mcmc)[[2]])
means = apply(mcmc[index,-removed], 2, mean)
SDs   = apply(mcmc[index,-removed], 2, sd)
## reference runs
removed = c(1, (dim(mcmc.ref)[[2]] - 2):dim(mcmc.ref)[[2]])
ref.means = apply(mcmc.ref[,-removed], 2, mean)
ref.SDs   = apply(mcmc.ref[,-removed], 2, sd)

## plot IT estimates vs. reference estimates
pdf("Theop MCMC vs TI posteriors.pdf")
par(mar=c(5,5,1,1))
mycols = c(rep("black",6), rep("green", 6), "blue", rep(heat.colors(6), each=6))
plot(exp(means), exp(ref.means), log="xy", las=1, col=mycols, pch=16,
     xlab="TI MCMC Posteriors", ylab="Standard MCMC Posteriors", cex.lab=1.3)
for (i in 1:length(means)) {
  lines(x=c(exp(means[i]), exp(means[i])), col=mycols[i],
        y=c(exp(ref.means[i]-ref.SDs[i]), exp(ref.means[i]+ref.SDs[i])))
}
for (i in 1:length(means)) {
  lines(y=c(exp(ref.means[i]), exp(ref.means[i])), col=mycols[i],
        x=c(exp(means[i]-SDs[i]), exp(means[i]+SDs[i])))
}
## should differentiate pop and indiv
abline(0,1)
legend(x=0.1, y=25,
       legend=c(expression(bold(mu)), expression(bold(Sigma^2)),
                expression(sigma^2),  expression(theta[1]),
                expression(theta[2]), expression(theta[3]),
                expression(theta[4]), expression(theta[5]),
                expression(theta[6])),
       fill=c("black", "green", "blue", heat.colors(6)),
       border=c("black", "green", "blue", heat.colors(6)))
dev.off()

## problem with Vr_lnKc2p.1? who else?
sort(ref.means - means)

pdf("Theoph Sigma kcp histograms.pdf")
par(mfrow=c(1,2))
par(mar=c(5,4,7,0))
hist(mcmc$Vr_lnKc2p.1.[index], 50, yaxt="n", ylab="", xlab="",
     main="", xlim=c(0,7)) # a mode way high...
text(3, 550, "A", cex=1.6)
par(mar=c(5,0,7,4))
hist(mcmc.ref$Vr_lnKc2p.1., 50, yaxt="n", ylab="", xlab="",
     main="", xlim=c(0,7))
text(3, 3120, "B", cex=1.6)
mtext(expression("Population variance of "*italic(k[cp])),
      side=1, line=3.3, at=c(-0.3), cex=1.5)
dev.off()

hist(mcmc$lnKp2c.1.2.[index])
hist(mcmc.ref$lnKp2c.1.2.)

## theoph parameter names: "kr", "ka", "V", "ke", "kcp", "kpc"
mylabs = c(1:13)
mylabs[1]  = expression(italic(mu[k[r]]))
mylabs[2]  = expression(italic(mu[k[a]]))
mylabs[3]  = expression(italic(mu[V]))
mylabs[4]  = expression(italic(mu[k[e]]))
mylabs[5]  = expression(italic(mu[k[cp]]))
mylabs[6]  = expression(italic(mu[k[pc]]))
mylabs[7]  = expression(italic({Sigma^2}[k[r]]))
mylabs[8]  = expression(italic({Sigma^2}[k[a]]))
mylabs[9]  = expression(italic({Sigma^2}[V]))
mylabs[10] = expression(italic({Sigma^2}[k[e]]))
mylabs[11] = expression(italic({Sigma^2}[k[cp]]))
mylabs[12] = expression(italic({Sigma^2}[k[pc]]))
mylabs[13] = expression(italic(sigma^2))
  
## boxplots of the TI parameter posteriors
##dev.new()
pdf("Theoph LTMCMC inter population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,2:14]), las=1, log="y", xaxt="n", outline=F, main="")
axis(1, at=1:13, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.2, 0.2,
            0.1, 0.1, 0.05, 0.1, 0.2, 0.2, -0.15))
text(0.6, 29, "A", cex=2)
dev.off()

pdf("Theoph LTMCMC inter individuals.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,15:50]), las=1, log="y", xaxt="n", outline=F, main="",
        at=2*(1:36), boxwex=0.50, pars=list(xlim=c(3.6, 70.4)))
abline(v=seq(13, 70, 12))
axis(1, at=seq(7.5, 78, 12), paste0("S",1:6), tick=F, cex.axis=1.5)
text(4, 40, "A", cex=2)
dev.off()

## boxplots of the reference MCMC parameter posteriors
pdf("Theoph MCMC inter population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc.ref[index,2:14]), las=1, log="y", xaxt="n", outline=F,
        main="")
axis(1, at=1:13, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.2, 0.2,
            0.1, 0.1, 0.05, 0.1, 0.2, 0.2, -0.15))
text(0.6, 29, "B", cex=2)
dev.off()

pdf("Theoph MCMC inter individuals.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc.ref[index,15:50]), las=1, log="y", xaxt="n", outline=F,
        main="",
        at=2*(1:36), boxwex=0.50, pars=list(xlim=c(3.6, 70.4)))
abline(v=seq(13, 70, 12))
axis(1, at=seq(7.5, 78, 12), paste0("S",1:6), tick=F, cex.axis=1.5)
text(4, 40, "B", cex=2)
dev.off()

## get the TI MPV
max(mcmc$LnPost[index])
index.mpv = which(mcmc$LnPost[index] == max(mcmc$LnPost[index]))
mcmc[index[index.mpv],]

## save the target sample
write.table(mcmc[index,], "theoph.LTMCMC.inter.at_target.dat",
            quote=F, row.names=F)

## write 20 random vectors and MPV at target
write.table(mcmc[sample(index, 20),],
            "theoph.LTMCMC_20+MPV.inter.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc[index[index.mpv],],
            "theoph.LTMCMC_20+MPV.inter.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## read fit check results
fit = read.delim("theoph.fit_LTMCMC.inter_MPV.out")

## plot data and predictions in time for each individual
## with 20 random runs
pdf("Theoph individual fits inter.pdf")
## outer margins
oma = c(4, 5, 0.5, 0.5)
mar = rep(0, 4)
par(oma = oma, mar = mar)
# 4x5 layout
nc = 5
lom = matrix(1:20, ncol = nc)
lo = layout(t(lom), widths = c(rep(1, nc)), heights = rep(1, nc),
            respect = TRUE)
las = 1
# adjust labels size
cex = 1
cex.axis = 1
mgp = c(2, 0.5, 0) * cex.axis 
tcl = -0.3
par(las = las, cex = cex, cex.axis = cex.axis,
    mgp = mgp, pty = "s", tcl = tcl)
n.subjects = max(fit$Simulation)
## labels for subjects
lab = c("S1i", "S1s", "S1sr", "S2i", "S2s", "S2sr", "S3i", "S3s", "S3sr",
        "S4i", "S4s", "S4sr", "S4srh",
        "S5i", "S5s", "S5sr", "S6i", "S6s", "S6sr", "S6srh")
par(mfrow=c(4,5))
for (i in 1:n.subjects) {
  index = which(fit$Sim == i)
  if (min(fit$Time[index]) == 1) {
    xlims = c(0, 13)
  } else {
    xlims = c(72, 85)
  }
  ylims = exp(c(0, 5)) # max(c(fit$Pred[index], fit$Data[index])))
  for (j in 1:20) {
    nom = paste0("theoph.fit_LTMCMC.inter_r", j, ".out")
    fitj = read.delim(nom)
    plot(fitj$Time[index], exp(fitj$Pred[index]), xlab="", ylab="", xaxt="n",
         yaxt="n", type="l", col="grey", lwd=1, xlim=xlims, ylim=ylims,
         log="y")
    par(new=T)
  }
  plot(fit$Time[index], exp(fit$Pred[index]), xlab="", ylab="", yaxt="n",
       xaxp=c(min(xlims)+2, max(xlims)+1, 3), log="y",
       type="l", col="red", lwd=2, xlim=xlims, ylim=ylims)
  points(fit$Time[index], exp(fit$Data[index]), pch=19, col="black")
  if (i == 18) mtext("Time (h)", side=1, line=3.4, cex=1.6)
  if (((i-1) %% 5) == 0) axis(2)
  if (i == 11) {
    mylab = expression("Plasma concentration ("*mu*"M)") 
    mtext(mylab, side=2, line=2.5, at=350, las=0, cex=1.6)
  }
  text(x = min(fit$Time[index])-1, y = 1.5, labels = lab[i], pos=4, cex=1.5)
}
dev.off()

## comparison of the MCMC and TI MCMC best posterior fits
pdf("Theoph MPV fits.pdf")
par(mar=c(5,5,1,1))
fit = read.delim("theoph.fit_LTMCMC.inter_MPV.out")
fit.ref = read.delim("../Reference runs inter/theoph.fit.out")
xlims = ylims = c(3, max(c(exp(fit$Data), exp(fit$Pred), exp(fit.ref$Pred))))
plot(exp(fit.ref$Pred), exp(fit.ref$Data), log="xy",
     las=1, xlim=xlims, yli=ylims, pch=20,
     xlab=expression("Predicted plasma concentration ("*mu*"M)"),
     ylab=expression("Observed plasma concentration ("*mu*"M)"),
     cex.lab=1.3)
par(new=T)
plot(exp(fit$Pred), exp(fit$Data), log="xy",
     las=1, xlim=xlims, yli=ylims, col="red",
     xlab="", ylab="", xaxt="n", yaxt="n")
abline(0,1)
legend(3.5, 100, c("MCMC", "TI MCMC"), pch=c(20, 1), col=c("black", "red"))
dev.off()

## get Pdata
pseudo.prior = tail(mcmc[grep("LnPseudoPrior.",names(mcmc))], 1)
lnPdata = as.numeric(pseudo.prior[1] - pseudo.prior[n_temper])
## taking occupancy into account:
occupancies = all.perks$counts[dim(all.perks$counts)[[1]],]
LnPdata = lnPdata + log(occupancies[n_temper]) - log(occupancies[1])
## -15.18271


## =======================================================================
## Theophylline with two-cpt model inter- and intra-individual variability

## --------------------
## likelihood tempering

setwd(base.dir)
setwd("theophylline/IT runs intra")

## get all perks
all.perks = get.all.perks("theoph.LTMCMC.intra.out.perks")

## plot the evolution of the temperature scale
pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## read tempered mcmc output
mcmc = read.delim("theoph.LTMCMC.intra.out")
dim(mcmc)

## read the reference mcmc output
mcmc.ref = read.delim("../Reference runs intra/theoph.final.dat")
dim(mcmc.ref)

perks = get.final.perks("theoph.LTMCMC.intra.out.perks")
n_temper = length(perks)

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
dev.off()

table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, 4, 5)

## Show posterior histograms for a parameter at a time
plot.post.histograms(mcmc, n_temper, parm=3)

## some stats
## TI runs
index = which(mcmc$IndexT==n_temper-1)
removed = c(1, (dim(mcmc)[[2]] - 3 - n_temper):dim(mcmc)[[2]])
means = apply(mcmc[index,-removed], 2, mean)
SDs   = apply(mcmc[index,-removed], 2, sd)
## reference runs
removed = c(1, (dim(mcmc.ref)[[2]] - 2):dim(mcmc.ref)[[2]])
ref.means = apply(mcmc.ref[,-removed], 2, mean)
ref.SDs   = apply(mcmc.ref[,-removed], 2, sd)

## plot IT estimates vs. reference estimates
par(mar=c(5,5,1,1))
plot(exp(means), exp(ref.means), log="xy", las=1,
     xlab="TI MCMC Posteriors", ylab="Standard MCMC Posteriors", cex.lab=1.3)
for (i in 1:length(means)) {
  lines(x=c(exp(means[i]), exp(means[i])),
        y=c(exp(ref.means[i]-ref.SDs[i]), exp(ref.means[i]+ref.SDs[i])))
}
for (i in 1:length(means)) {
  lines(y=c(exp(ref.means[i]), exp(ref.means[i])),
        x=c(exp(means[i]-SDs[i]), exp(means[i]+SDs[i])))
}
## should differentiate pop and indiv
abline(0,1)

## problems
sort(ref.means - means)
hist(mcmc$Vr_lnKp2c.1.[index])
hist(mcmc.ref$Vr_lnKp2c.1.)
hist(mcmc$lnKp2c.1.2.[index])
hist(mcmc.ref$lnKp2c.1.2.)

## theoph parameter names: "kr", "ka", "V", "ke", "kcp", "kpc"
mylabs = c(1:13)
mylabs[1]  = expression(italic(mu[k[r]]))
mylabs[2]  = expression(italic(mu[k[a]]))
mylabs[3]  = expression(italic(mu[V]))
mylabs[4]  = expression(italic(mu[k[e]]))
mylabs[5]  = expression(italic(mu[k[cp]]))
mylabs[6]  = expression(italic(mu[k[pc]]))
mylabs[7]  = expression(italic(Sigma[k[r]]))
mylabs[8]  = expression(italic(Sigma[k[a]]))
mylabs[9]  = expression(italic(Sigma[V]))
mylabs[10] = expression(italic(Sigma[k[e]]))
mylabs[11] = expression(italic(Sigma[k[cp]]))
mylabs[12] = expression(italic(Sigma[k[pc]]))
mylabs[13] = expression(italic(sigma^2))
  
## boxplots of the TI parameter posteriors
##dev.new()
pdf("Theoph LTMCMC inter population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,2:14]), las=1, log="y", xaxt="n", outline=F, main="")
axis(1, at=1:13, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.2, 0.2, 0.1, 0.1, 0, 0.1, 0.2, 0.2, -0.15))
text(0.6, 29, "A", cex=2)
dev.off()

pdf("Theoph LTMCMC inter individuals.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,15:50]), las=1, log="y", xaxt="n", outline=F, main="",
        at=2*(1:36), boxwex=0.50, pars=list(xlim=c(3.6, 70.4)))
abline(v=seq(13, 70, 12))
axis(1, at=seq(7.5, 78, 12), paste0("S",1:6), tick=F, cex.axis=1.5)
text(4, 40, "A", cex=2)
dev.off()

## boxplots of the reference MCMC parameter posteriors
pdf("Theoph MCMC inter population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc.ref[index,2:14]), las=1, log="y", xaxt="n", outline=F,
        main="")
axis(1, at=1:13, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.2, 0.2, 0.1, 0.1, 0, 0.1, 0.2, 0.2, -0.15))
text(0.6, 29, "B", cex=2)
dev.off()

pdf("Theoph MCMC inter individuals.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc.ref[index,15:50]), las=1, log="y", xaxt="n", outline=F,
        main="",
        at=2*(1:36), boxwex=0.50, pars=list(xlim=c(3.6, 70.4)))
abline(v=seq(13, 70, 12))
axis(1, at=seq(7.5, 78, 12), paste0("S",1:6), tick=F, cex.axis=1.5)
text(4, 40, "B", cex=2)
dev.off()

## get the TI MPV
max(mcmc$LnPost[index])
index.mpv = which(mcmc$LnPost[index] == max(mcmc$LnPost[index]))
mcmc[index[index.mpv],]

## save the target sample
write.table(mcmc[index,], "theoph.LTMCMC.intra.at_target.dat",
            quote=F, row.names=F)

## write 20 random vectors and MPV at target
write.table(mcmc[sample(index, 20),],
            "theoph.LTMCMC_20+MPV.intra.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc[index[index.mpv],],
            "theoph.LTMCMC_20+MPV.intra.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## read fit check results
fit = read.delim("theoph.fit_LTMCMC.intra_MPV.out")

## plot data and predictions in time for each individual
## with 20 random runs
pdf("Theoph individual fits intra.pdf")
## outer margins
oma = c(4, 5, 0.5, 0.5)
mar = rep(0, 4)
par(oma = oma, mar = mar)
# 4x5 layout
nc = 5
lom = matrix(1:20, ncol = nc)
lo = layout(t(lom), widths = c(rep(1, nc)), heights = rep(1, nc),
            respect = TRUE)
las = 1
# adjust labels size
cex = 1
cex.axis = 1
mgp = c(2, 0.5, 0) * cex.axis 
tcl = -0.3
par(las = las, cex = cex, cex.axis = cex.axis,
    mgp = mgp, pty = "s", tcl = tcl)
n.subjects = max(fit$Simulation)
## labels for subjects
lab = c("S1i", "S1s", "S1sr", "S2i", "S2s", "S2sr", "S3i", "S3s", "S3sr",
        "S4i", "S4s", "S4sr", "S4srh",
        "S5i", "S5s", "S5sr", "S6i", "S6s", "S6sr", "S6srh")
par(mfrow=c(4,5))
for (i in 1:n.subjects) {
  index = which(fit$Sim == i)
  if (min(fit$Time[index]) == 1) {
    xlims = c(0, 13)
  } else {
    xlims = c(72, 85)
  }
  ylims = exp(c(0, 5)) # max(c(fit$Pred[index], fit$Data[index])))
  for (j in 1:20) {
    nom = paste0("theoph.fit_LTMCMC.intra_r", j, ".out")
    fitj = read.delim(nom)
    plot(fitj$Time[index], exp(fitj$Pred[index]), xlab="", ylab="", xaxt="n",
         yaxt="n", type="l", col="grey", lwd=1, xlim=xlims, ylim=ylims,
         log="y")
    par(new=T)
  }
  plot(fit$Time[index], exp(fit$Pred[index]), xlab="", ylab="", yaxt="n",
       xaxp=c(min(xlims)+2, max(xlims)+1, 3), log="y",
       type="l", col="red", lwd=2, xlim=xlims, ylim=ylims)
  points(fit$Time[index], exp(fit$Data[index]), pch=19, col="black")
  if (i == 18) mtext("Time (h)", side=1, line=3.4, cex=1.6)
  if (((i-1) %% 5) == 0) axis(2)
  if (i == 11) {
    mylab = expression("Plasma concentration ("*mu*"M)") 
    mtext(mylab, side=2, line=2.5, at=350, las=0, cex=1.6)
  }
  text(x = min(fit$Time[index])-1, y = 1.5, labels = lab[i], pos=4, cex=1.5)
}
dev.off()

## comparison of the MCMC and TI MCMC best posterior fits
pdf("Theoph MPV fits.pdf")
par(mar=c(5,5,1,1))
fit = read.delim("theoph.fit_LTMCMC.inter_MPV.out")
fit.ref = read.delim("../Reference runs inter/theoph.fit.out")
xlims = ylims = c(3, max(c(exp(fit$Data), exp(fit$Pred), exp(fit.ref$Pred))))
plot(exp(fit.ref$Pred), exp(fit.ref$Data), log="xy",
     las=1, xlim=xlims, yli=ylims, pch=20,
     xlab=expression("Predicted plasma concentration ("*mu*"M)"),
     ylab=expression("Observed plasma concentration ("*mu*"M)"),
     cex.lab=1.3)
par(new=T)
plot(exp(fit$Pred), exp(fit$Data), log="xy",
     las=1, xlim=xlims, yli=ylims, col="red",
     xlab="", ylab="", xaxt="n", yaxt="n")
abline(0,1)
legend(3.5, 100, c("MCMC", "TI MCMC"), pch=c(20, 1), col=c("black", "red"))
dev.off()

## get Pdata
pseudo.prior = tail(mcmc[grep("LnPseudoPrior.",names(mcmc))], 1)
lnPdata = as.numeric(pseudo.prior[1] - pseudo.prior[n_temper])
## taking occupancy into account:
occupancies = all.perks$counts[dim(all.perks$counts)[[1]],]
LnPdata = lnPdata + log(occupancies[n_temper]) - log(occupancies[1])
## 5.545707


## =======================================================
## Theophylline one-cpt model inter-individual variability

## --------------------
## likelihood tempering

setwd(base.dir)
setwd("theophylline/IT runs inter 1cpt")

## get all perks
all.perks = get.all.perks("theoph_1cpt.LTMCMC.inter.out.perks")

## plot the evolution of the temperature scale
pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## read tempered mcmc output
mcmc = read.delim("theoph_1cpt.LTMCMC.inter.out")
dim(mcmc)

## read the reference mcmc output
mcmc.ref = read.delim("../Reference runs inter/theoph.final.dat")
dim(mcmc.ref)

perks = get.final.perks("theoph_1cpt.LTMCMC.inter.out.perks")
n_temper = length(perks)

## plot last perks and pseudo-priors
par(mar=c(5, 5, 2, 1))
lnpseudos = as.numeric(all.perks$lnpi[dim(all.perks$lnpi)[1],])
lnpseudos = lnpseudos - min(lnpseudos, na.rm=T) + 1
lnpseudos = lnpseudos[1:which(perks==1)]
plot(as.numeric(perks), lnpseudos, las=1,
     xlab="Perks", ylab="Log pseudo-prior", cex.lab=1.4,
     type="b", lwd=2, xlim=c(1E-7,1), log="xy")

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
dev.off()

table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, 4, 5)

## Show posterior histograms for a parameter at a time
plot.post.histograms(mcmc, n_temper, parm=3)

## some stats
## TI runs
index = which(mcmc$IndexT==n_temper-1)
removed = c(1, (dim(mcmc)[[2]] - 3 - n_temper):dim(mcmc)[[2]])
means = apply(mcmc[index,-removed], 2, mean)
SDs   = apply(mcmc[index,-removed], 2, sd)
## reference runs
removed = c(1, (dim(mcmc.ref)[[2]] - 2):dim(mcmc.ref)[[2]])
ref.means = apply(mcmc.ref[,-removed], 2, mean)
ref.SDs   = apply(mcmc.ref[,-removed], 2, sd)

## theoph parameter names: "kr", "ka", "V", "ke"
mylabs = c(1:9)
mylabs[1]  = expression(italic(mu[k[r]]))
mylabs[2]  = expression(italic(mu[k[a]]))
mylabs[3]  = expression(italic(mu[V]))
mylabs[4]  = expression(italic(mu[k[e]]))
mylabs[5]  = expression(italic(Sigma[k[r]]))
mylabs[6]  = expression(italic(Sigma[k[a]]))
mylabs[7]  = expression(italic(Sigma[V]))
mylabs[8]  = expression(italic(Sigma[k[e]]))
mylabs[9]  = expression(italic(sigma^2))
  
## boxplots of the TI parameter posteriors
##dev.new()
pdf("Theoph 1cpt LTMCMC inter population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,2:10]), las=1, log="y", xaxt="n", outline=F, main="")
axis(1, at=1:9, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.1, 0.1, 0, 0.1, -0.15))
text(0.6, 29, "A", cex=2)
dev.off()

pdf("Theoph 1cpt LTMCMC inter individuals.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,11:34]), las=1, log="y", xaxt="n", outline=F, main="",
        at=2*(1:24), boxwex=0.50, pars=list(xlim=c(3, 47)))
abline(v=seq(9, 49, 8))
axis(1, at=seq(5, 49, 8), paste0("S",1:6), tick=F, cex.axis=1.5)
text(3, 25, "A", cex=2)
dev.off()

## get the TI MPV
max(mcmc$LnPost[index])
index.mpv = which(mcmc$LnPost[index] == max(mcmc$LnPost[index]))
mcmc[index[index.mpv],]

## save the target sample
write.table(mcmc[index,], "theoph_1cpt.LTMCMC.inter.at_target.dat",
            quote=F, row.names=F)

## write 20 random vectors and MPV at target
write.table(mcmc[sample(index, 20),],
            "theoph_1cpt.LTMCMC_20+MPV.inter.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc[index[index.mpv],],
            "theoph_1cpt.LTMCMC_20+MPV.inter.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## read fit check results
fit = read.delim("theoph_1cpt.fit_LTMCMC.inter_MPV.out")

## plot data and predictions in time for each individual
## with 20 random runs
pdf("Theoph 1cpt individual fits inter.pdf")
## outer margins
oma = c(4, 5, 0.5, 0.5)
mar = rep(0, 4)
par(oma = oma, mar = mar)
# 4x5 layout
nc = 5
lom = matrix(1:20, ncol = nc)
lo = layout(t(lom), widths = c(rep(1, nc)), heights = rep(1, nc),
            respect = TRUE)
las = 1
# adjust labels size
cex = 1
cex.axis = 1
mgp = c(2, 0.5, 0) * cex.axis 
tcl = -0.3
par(las = las, cex = cex, cex.axis = cex.axis,
    mgp = mgp, pty = "s", tcl = tcl)
n.subjects = max(fit$Simulation)
## labels for subjects
lab = c("S1i", "S1s", "S1sr", "S2i", "S2s", "S2sr", "S3i", "S3s", "S3sr",
        "S4i", "S4s", "S4sr", "S4srh",
        "S5i", "S5s", "S5sr", "S6i", "S6s", "S6sr", "S6srh")
par(mfrow=c(4,5))
for (i in 1:n.subjects) {
  index = which(fit$Sim == i)
  if (min(fit$Time[index]) == 1) {
    xlims = c(0, 13)
  } else {
    xlims = c(72, 85)
  }
  ylims = exp(c(0, 5)) # max(c(fit$Pred[index], fit$Data[index])))
  for (j in 1:20) {
    nom = paste0("theoph_1cpt.fit_LTMCMC.inter_r", j, ".out")
    fitj = read.delim(nom)
    plot(fitj$Time[index], exp(fitj$Pred[index]), xlab="", ylab="", xaxt="n",
         yaxt="n", type="l", col="grey", lwd=1, xlim=xlims, ylim=ylims,
         log="y")
    par(new=T)
  }
  plot(fit$Time[index], exp(fit$Pred[index]), xlab="", ylab="", yaxt="n",
       xaxp=c(min(xlims)+2, max(xlims)+1, 3), log="y",
       type="l", col="red", lwd=2, xlim=xlims, ylim=ylims)
  points(fit$Time[index], exp(fit$Data[index]), pch=19, col="black")
  if (i == 18) mtext("Time (h)", side=1, line=3.4, cex=1.6)
  if (((i-1) %% 5) == 0) axis(2)
  if (i == 11) {
    mylab = expression("Plasma concentration ("*mu*"M)") 
    mtext(mylab, side=2, line=2.5, at=350, las=0, cex=1.6)
  }
  text(x = min(fit$Time[index])-1, y = 1.5, labels = lab[i], pos=4, cex=1.5)
}
dev.off()

## get Pdata
pseudo.prior = tail(mcmc[grep("LnPseudoPrior.",names(mcmc))], 1)
lnPdata = as.numeric(pseudo.prior[1] - pseudo.prior[n_temper])
## taking occupancy into account:
occupancies = all.perks$counts[dim(all.perks$counts)[[1]],]
LnPdata = lnPdata + log(occupancies[n_temper]) - log(occupancies[1])
## -14.9798


## ==================================================================
## Theophylline one-cpt model inter- and intra-individual variability

## --------------------
## likelihood tempering

setwd(base.dir)
setwd("theophylline/IT runs intra 1cpt")

## get all perks
all.perks = get.all.perks("theoph_1cpt.LTMCMC.intra.out.perks")

## plot the evolution of the temperature scale
pdf("Perk scale evolution.pdf")
plot.all.perks(all.perks, mylog="")
dev.off()

## read tempered mcmc output
mcmc = read.delim("theoph_1cpt.LTMCMC.intra.out")
dim(mcmc)

## read the reference mcmc output
## mcmc.ref = read.delim("../Reference runs intra/theoph.final.dat")
## dim(mcmc.ref)

perks = get.final.perks("theoph_1cpt.LTMCMC.intra.out.perks")
n_temper = length(perks)

## plot last perks and pseudo-priors
par(mar=c(5, 5, 2, 1))
lnpseudos = as.numeric(all.perks$lnpi[dim(all.perks$lnpi)[1],])
lnpseudos = lnpseudos - min(lnpseudos, na.rm=T) + 1
lnpseudos = lnpseudos[1:which(perks==1)]
plot(as.numeric(perks), lnpseudos, las=1,
     xlab="Perks", ylab="Log pseudo-prior", cex.lab=1.4,
     type="b", lwd=2, xlim=c(1E-7,1), log="xy")

## check
head(mcmc[grep("LnPseudoPrior.",names(mcmc))])

## plot the temperatures visits
pdf("Temperature visits.pdf")
plot.perks.visits(mcmc, n_temper)
dev.off()

table(mcmc$IndexT)

## plot Robbins-Monro pseudo-priors updating 
plot.Robbins_Monro(mcmc, n_temper, 4, 5)

## Show posterior histograms for a parameter at a time
plot.post.histograms(mcmc, n_temper, parm=3)

## some stats
## TI runs
index = which(mcmc$IndexT==n_temper-1)
removed = c(1, (dim(mcmc)[[2]] - 3 - n_temper):dim(mcmc)[[2]])
means = apply(mcmc[index,-removed], 2, mean)
SDs   = apply(mcmc[index,-removed], 2, sd)

## theoph parameter names: "kr", "ka", "V", "ke"
mylabs = c(1:9)
mylabs[1]  = expression(italic(mu[k[r]]))
mylabs[2]  = expression(italic(mu[k[a]]))
mylabs[3]  = expression(italic(mu[V]))
mylabs[4]  = expression(italic(mu[k[e]]))
mylabs[5]  = expression(italic({Sigma^2}[k[r]]))
mylabs[6]  = expression(italic({Sigma^2}[k[a]]))
mylabs[7]  = expression(italic({Sigma^2}[V]))
mylabs[8]  = expression(italic({Sigma^2}[k[e]]))
mylabs[9]  = expression(italic({Xi^2}[k[r]]))
mylabs[10] = expression(italic({Xi^2}[k[a]]))
mylabs[11] = expression(italic({Xi^2}[V]))
mylabs[12] = expression(italic({Xi^2}[k[e]]))
mylabs[13] = expression(italic(sigma^2))
  
## boxplots of the TI parameter posteriors
##dev.new()
pdf("Theoph 1cpt LTMCMC intra population.pdf")
par(mar=c(4,4,1,1))
boxplot(exp(mcmc[index,2:14]), las=1, log="y", xaxt="n", outline=F, main="")
axis(1, at=1:13, labels=mylabs,
     padj=c(0, 0, 0, 0.1, 0.1, 0.1, 0, 0.1, 0.1, 0.1, 0.05, 0.1, -0.15))
text(0.6, 20, "A", cex=2)
dev.off()

pdf("Theoph 1cpt LTMCMC intra individuals.pdf")
par(mar=c(4,4,1,1))
i = c(15:18, 31:34, 47:50, 63:66, 83:86, 99:102)
boxplot(exp(mcmc[index,i]), las=1, log="y", xaxt="n", outline=F, main="",
        at=2*(1:length(i)), boxwex=0.50, pars=list(xlim=c(3, 47)))
abline(v=seq(9, 49, 8))
axis(1, at=seq(5, 49, 8), paste0("S",1:6), tick=F, cex.axis=1.5)
text(3, 38, "B", cex=2)
dev.off()

## get the TI MPV
max(mcmc$LnPost[index])
index.mpv = which(mcmc$LnPost[index] == max(mcmc$LnPost[index]))
mcmc[index[index.mpv],]

## save the target sample
write.table(mcmc[index,], "theoph_1cpt.LTMCMC.intra.at_target.dat",
            quote=F, row.names=F)

## write 20 random vectors and MPV at target
write.table(mcmc[sample(index, 20),],
            "theoph_1cpt.LTMCMC_20+MPV.intra.at_target.dat",
            quote=F, row.names=F)
write.table(mcmc[index[index.mpv],],
            "theoph_1cpt.LTMCMC_20+MPV.intra.at_target.dat",
            append=T, quote=F, row.names=F, col.names=F)

## read fit check results
fit = read.delim("theoph_1cpt.fit_LTMCMC.intra_MPV.out")

## plot data and predictions in time for each individual
## with 20 random runs
pdf("Theoph 1cpt individual fits intra.pdf")
## outer margins
oma = c(4, 5, 0.5, 0.5)
mar = rep(0, 4)
par(oma = oma, mar = mar)
# 4x5 layout
nc = 5
lom = matrix(1:20, ncol = nc)
lo = layout(t(lom), widths = c(rep(1, nc)), heights = rep(1, nc),
            respect = TRUE)
las = 1
# adjust labels size
cex = 1
cex.axis = 1
mgp = c(2, 0.5, 0) * cex.axis 
tcl = -0.3
par(las = las, cex = cex, cex.axis = cex.axis,
    mgp = mgp, pty = "s", tcl = tcl)
n.subjects = max(fit$Simulation)
## labels for subjects
lab = c("S1i", "S1s", "S1sr", "S2i", "S2s", "S2sr", "S3i", "S3s", "S3sr",
        "S4i", "S4s", "S4sr", "S4srh",
        "S5i", "S5s", "S5sr", "S6i", "S6s", "S6sr", "S6srh")
par(mfrow=c(4,5))
for (i in 1:n.subjects) {
  index = which(fit$Sim == i)
  if (min(fit$Time[index]) == 1) {
    xlims = c(0, 13)
  } else {
    xlims = c(72, 85)
  }
  ylims = exp(c(0, 5)) # max(c(fit$Pred[index], fit$Data[index])))
  for (j in 1:20) {
    nom = paste0("theoph_1cpt.fit_LTMCMC.intra_r", j, ".out")
    fitj = read.delim(nom)
    plot(fitj$Time[index], exp(fitj$Pred[index]), xlab="", ylab="", xaxt="n",
         yaxt="n", type="l", col="grey", lwd=1, xlim=xlims, ylim=ylims,
         log="y")
    par(new=T)
  }
  plot(fit$Time[index], exp(fit$Pred[index]), xlab="", ylab="", yaxt="n",
       xaxp=c(min(xlims)+2, max(xlims)+1, 3), log="y",
       type="l", col="red", lwd=2, xlim=xlims, ylim=ylims)
  points(fit$Time[index], exp(fit$Data[index]), pch=19, col="black")
  if (i == 18) mtext("Time (h)", side=1, line=3.4, cex=1.6)
  if (((i-1) %% 5) == 0) axis(2)
  if (i == 11) {
    mylab = expression("Plasma concentration ("*mu*"M)") 
    mtext(mylab, side=2, line=2.5, at=350, las=0, cex=1.6)
  }
  text(x = min(fit$Time[index])-1, y = 1.5, labels = lab[i], pos=4, cex=1.5)
}
dev.off()

## get Pdata
pseudo.prior = tail(mcmc[grep("LnPseudoPrior.",names(mcmc))], 1)
lnPdata = as.numeric(pseudo.prior[1] - pseudo.prior[n_temper])
## taking occupancy into account:
occupancies = all.perks$counts[dim(all.perks$counts)[[1]],]
LnPdata = lnPdata + log(occupancies[n_temper]) - log(occupancies[1])
## 8.727811

## End.
