/* model.c
   ___________________________________________________

   Model File:  Two-compartment_v2.model

   Date:  Sun Aug  5 19:56:40 2018

   Created by:  "mod v6.0.1"
    -- a model preprocessor by Don Maszle
   ___________________________________________________

   Copyright (c) 1993-2018 Free Software Foundation, Inc.

   Model calculations for compartmental model:

   5 States:
     Q_central -> 0.0;
     Q_periph -> 0.0;
     Q_to_release -> 0.0;
     Q_gi -> 0.0;
     Q_elim -> 0.0;

   8 Outputs:
     C_central -> 0.0;
     Q_total -> 0.0;
     lnQ_to_release -> 0.0;
     lnQ_gi -> 0.0;
     lnQ_periph -> 0.0;
     lnQ_elim -> 0.0;
     lnQ_total -> 0.0;
     lnC_central -> 0.0;

   2 Inputs:
     PO_dose (is a function)
     IV_dose_rate (is a function)

   35 Parameters:
     G_immediate = 1;
     G_delayed = 0;
     Period = 12.0;
     TChng = 0.01;
     Kr = 0;
     Ka = 0;
     Ke = 0;
     lnKr = log(1.0);
     lnKa = log(1.0);
     lnKe = log(0.05);
     V_central = 0;
     lnV_central = log(0.3);
     Kc2p = 0;
     Kp2c = 0;
     lnKc2p = log(11);
     lnKp2c = log(5);
     M_lnKr = 0;
     M_lnKa = 0;
     M_lnKe = 0;
     M_lnV_central = 0;
     M_lnKc2p = 0;
     M_lnKp2c = 0;
     Vr_lnKr = 0;
     Vr_lnKa = 0;
     Vr_lnKe = 0;
     Vr_lnV_central = 0;
     Vr_lnKc2p = 0;
     Vr_lnKp2c = 0;
     Va_lnKr = 0;
     Va_lnKa = 0;
     Va_lnKe = 0;
     Va_lnV_central = 0;
     Va_lnKc2p = 0;
     Va_lnKp2c = 0;
     Ve_lnC_central = 0;
*/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <float.h>
#include "modelu.h"
#include "random.h"
#include "yourcode.h"


/*----- Indices to Global Variables */

/* Model variables: States and other outputs */
#define ID_Q_central 0x00000
#define ID_Q_periph 0x00001
#define ID_Q_to_release 0x00002
#define ID_Q_gi 0x00003
#define ID_Q_elim 0x00004
#define ID_C_central 0x00005
#define ID_Q_total 0x00006
#define ID_lnQ_to_release 0x00007
#define ID_lnQ_gi 0x00008
#define ID_lnQ_periph 0x00009
#define ID_lnQ_elim 0x0000a
#define ID_lnQ_total 0x0000b
#define ID_lnC_central 0x0000c

/* Inputs */
#define ID_PO_dose 0x00000
#define ID_IV_dose_rate 0x00001

/* Parameters */
#define ID_G_immediate 0x0000f
#define ID_G_delayed 0x00010
#define ID_Period 0x00011
#define ID_TChng 0x00012
#define ID_Kr 0x00013
#define ID_Ka 0x00014
#define ID_Ke 0x00015
#define ID_lnKr 0x00016
#define ID_lnKa 0x00017
#define ID_lnKe 0x00018
#define ID_V_central 0x00019
#define ID_lnV_central 0x0001a
#define ID_Kc2p 0x0001b
#define ID_Kp2c 0x0001c
#define ID_lnKc2p 0x0001d
#define ID_lnKp2c 0x0001e
#define ID_M_lnKr 0x0001f
#define ID_M_lnKa 0x00020
#define ID_M_lnKe 0x00021
#define ID_M_lnV_central 0x00022
#define ID_M_lnKc2p 0x00023
#define ID_M_lnKp2c 0x00024
#define ID_Vr_lnKr 0x00025
#define ID_Vr_lnKa 0x00026
#define ID_Vr_lnKe 0x00027
#define ID_Vr_lnV_central 0x00028
#define ID_Vr_lnKc2p 0x00029
#define ID_Vr_lnKp2c 0x0002a
#define ID_Va_lnKr 0x0002b
#define ID_Va_lnKa 0x0002c
#define ID_Va_lnKe 0x0002d
#define ID_Va_lnV_central 0x0002e
#define ID_Va_lnKc2p 0x0002f
#define ID_Va_lnKp2c 0x00030
#define ID_Ve_lnC_central 0x00031


/*----- Global Variables */

/* For export. Keep track of who we are. */
char szModelDescFilename[] = "Two-compartment_v2.model";
char szModelSourceFilename[] = __FILE__;
char szModelGenAndVersion[] = "mod v6.0.1";

/* Externs */
extern BOOL vbModelReinitd;

/* Model Dimensions */
int vnStates = 5;
int vnOutputs = 8;
int vnModelVars = 13;
int vnInputs = 2;
int vnParms = 35;

/* States and Outputs*/
double vrgModelVars[13];

/* Inputs */
IFN vrgInputs[2];

/* Parameters */
double G_immediate;
double G_delayed;
double Period;
double TChng;
double Kr;
double Ka;
double Ke;
double lnKr;
double lnKa;
double lnKe;
double V_central;
double lnV_central;
double Kc2p;
double Kp2c;
double lnKc2p;
double lnKp2c;
double M_lnKr;
double M_lnKa;
double M_lnKe;
double M_lnV_central;
double M_lnKc2p;
double M_lnKp2c;
double Vr_lnKr;
double Vr_lnKa;
double Vr_lnKe;
double Vr_lnV_central;
double Vr_lnKc2p;
double Vr_lnKp2c;
double Va_lnKr;
double Va_lnKa;
double Va_lnKe;
double Va_lnV_central;
double Va_lnKc2p;
double Va_lnKp2c;
double Ve_lnC_central;

BOOL bDelays = 0;


/*----- Global Variable Map */

VMMAPSTRCT vrgvmGlo[] = {
  {"Q_central", (PVOID) &vrgModelVars[ID_Q_central], ID_STATE | ID_Q_central},
  {"Q_periph", (PVOID) &vrgModelVars[ID_Q_periph], ID_STATE | ID_Q_periph},
  {"Q_to_release", (PVOID) &vrgModelVars[ID_Q_to_release], ID_STATE | ID_Q_to_release},
  {"Q_gi", (PVOID) &vrgModelVars[ID_Q_gi], ID_STATE | ID_Q_gi},
  {"Q_elim", (PVOID) &vrgModelVars[ID_Q_elim], ID_STATE | ID_Q_elim},
  {"C_central", (PVOID) &vrgModelVars[ID_C_central], ID_OUTPUT | ID_C_central},
  {"Q_total", (PVOID) &vrgModelVars[ID_Q_total], ID_OUTPUT | ID_Q_total},
  {"lnQ_to_release", (PVOID) &vrgModelVars[ID_lnQ_to_release], ID_OUTPUT | ID_lnQ_to_release},
  {"lnQ_gi", (PVOID) &vrgModelVars[ID_lnQ_gi], ID_OUTPUT | ID_lnQ_gi},
  {"lnQ_periph", (PVOID) &vrgModelVars[ID_lnQ_periph], ID_OUTPUT | ID_lnQ_periph},
  {"lnQ_elim", (PVOID) &vrgModelVars[ID_lnQ_elim], ID_OUTPUT | ID_lnQ_elim},
  {"lnQ_total", (PVOID) &vrgModelVars[ID_lnQ_total], ID_OUTPUT | ID_lnQ_total},
  {"lnC_central", (PVOID) &vrgModelVars[ID_lnC_central], ID_OUTPUT | ID_lnC_central},
  {"PO_dose", (PVOID) &vrgInputs[ID_PO_dose], ID_INPUT | ID_PO_dose},
  {"IV_dose_rate", (PVOID) &vrgInputs[ID_IV_dose_rate], ID_INPUT | ID_IV_dose_rate},
  {"G_immediate", (PVOID) &G_immediate, ID_PARM | ID_G_immediate},
  {"G_delayed", (PVOID) &G_delayed, ID_PARM | ID_G_delayed},
  {"Period", (PVOID) &Period, ID_PARM | ID_Period},
  {"TChng", (PVOID) &TChng, ID_PARM | ID_TChng},
  {"Kr", (PVOID) &Kr, ID_PARM | ID_Kr},
  {"Ka", (PVOID) &Ka, ID_PARM | ID_Ka},
  {"Ke", (PVOID) &Ke, ID_PARM | ID_Ke},
  {"lnKr", (PVOID) &lnKr, ID_PARM | ID_lnKr},
  {"lnKa", (PVOID) &lnKa, ID_PARM | ID_lnKa},
  {"lnKe", (PVOID) &lnKe, ID_PARM | ID_lnKe},
  {"V_central", (PVOID) &V_central, ID_PARM | ID_V_central},
  {"lnV_central", (PVOID) &lnV_central, ID_PARM | ID_lnV_central},
  {"Kc2p", (PVOID) &Kc2p, ID_PARM | ID_Kc2p},
  {"Kp2c", (PVOID) &Kp2c, ID_PARM | ID_Kp2c},
  {"lnKc2p", (PVOID) &lnKc2p, ID_PARM | ID_lnKc2p},
  {"lnKp2c", (PVOID) &lnKp2c, ID_PARM | ID_lnKp2c},
  {"M_lnKr", (PVOID) &M_lnKr, ID_PARM | ID_M_lnKr},
  {"M_lnKa", (PVOID) &M_lnKa, ID_PARM | ID_M_lnKa},
  {"M_lnKe", (PVOID) &M_lnKe, ID_PARM | ID_M_lnKe},
  {"M_lnV_central", (PVOID) &M_lnV_central, ID_PARM | ID_M_lnV_central},
  {"M_lnKc2p", (PVOID) &M_lnKc2p, ID_PARM | ID_M_lnKc2p},
  {"M_lnKp2c", (PVOID) &M_lnKp2c, ID_PARM | ID_M_lnKp2c},
  {"Vr_lnKr", (PVOID) &Vr_lnKr, ID_PARM | ID_Vr_lnKr},
  {"Vr_lnKa", (PVOID) &Vr_lnKa, ID_PARM | ID_Vr_lnKa},
  {"Vr_lnKe", (PVOID) &Vr_lnKe, ID_PARM | ID_Vr_lnKe},
  {"Vr_lnV_central", (PVOID) &Vr_lnV_central, ID_PARM | ID_Vr_lnV_central},
  {"Vr_lnKc2p", (PVOID) &Vr_lnKc2p, ID_PARM | ID_Vr_lnKc2p},
  {"Vr_lnKp2c", (PVOID) &Vr_lnKp2c, ID_PARM | ID_Vr_lnKp2c},
  {"Va_lnKr", (PVOID) &Va_lnKr, ID_PARM | ID_Va_lnKr},
  {"Va_lnKa", (PVOID) &Va_lnKa, ID_PARM | ID_Va_lnKa},
  {"Va_lnKe", (PVOID) &Va_lnKe, ID_PARM | ID_Va_lnKe},
  {"Va_lnV_central", (PVOID) &Va_lnV_central, ID_PARM | ID_Va_lnV_central},
  {"Va_lnKc2p", (PVOID) &Va_lnKc2p, ID_PARM | ID_Va_lnKc2p},
  {"Va_lnKp2c", (PVOID) &Va_lnKp2c, ID_PARM | ID_Va_lnKp2c},
  {"Ve_lnC_central", (PVOID) &Ve_lnC_central, ID_PARM | ID_Ve_lnC_central},
  {"", NULL, 0} /* End flag */
};  /* vrgpvmGlo[] */


/*----- InitModel
   Should be called to initialize model variables at
   the beginning of experiment before reading
   variants from the simulation spec file.
*/

void InitModel(void)
{
  /* Initialize things in the order that they appear in
     model definition file so that dependencies are
     handled correctly. */

  vrgModelVars[ID_Q_central] = 0.0;
  vrgModelVars[ID_Q_periph] = 0.0;
  vrgModelVars[ID_Q_to_release] = 0.0;
  vrgModelVars[ID_Q_gi] = 0.0;
  vrgModelVars[ID_Q_elim] = 0.0;
  vrgModelVars[ID_C_central] = 0.0;
  vrgModelVars[ID_Q_total] = 0.0;
  vrgModelVars[ID_lnQ_to_release] = 0.0;
  vrgModelVars[ID_lnQ_gi] = 0.0;
  vrgModelVars[ID_lnQ_periph] = 0.0;
  vrgModelVars[ID_lnQ_elim] = 0.0;
  vrgModelVars[ID_lnQ_total] = 0.0;
  vrgModelVars[ID_lnC_central] = 0.0;
  vrgInputs[ID_PO_dose].iType = IFN_PERDOSE;
  vrgInputs[ID_PO_dose].dTStartPeriod = 0;
  vrgInputs[ID_PO_dose].bOn = FALSE;
  vrgInputs[ID_PO_dose].dMag = 1.000000;
  vrgInputs[ID_PO_dose].dT0 = 0.000000;
  vrgInputs[ID_PO_dose].dTexp = 0.010000;
  vrgInputs[ID_PO_dose].dDecay = 0.000000;
  vrgInputs[ID_PO_dose].dTper = 0.000000;
  vrgInputs[ID_PO_dose].hMag = 0;
  vrgInputs[ID_PO_dose].hT0 = 0;
  vrgInputs[ID_PO_dose].hTexp = 0;
  vrgInputs[ID_PO_dose].hDecay = 0;
  vrgInputs[ID_PO_dose].hTper = 0x40011;
  vrgInputs[ID_PO_dose].dVal = 0.0;
  vrgInputs[ID_PO_dose].nDoses = 0;
  vrgInputs[ID_IV_dose_rate].iType = IFN_CONSTANT;
  vrgInputs[ID_IV_dose_rate].dTStartPeriod = 0;
  vrgInputs[ID_IV_dose_rate].bOn = FALSE;
  vrgInputs[ID_IV_dose_rate].dMag = 0.000000;
  vrgInputs[ID_IV_dose_rate].dT0 = 0.000000;
  vrgInputs[ID_IV_dose_rate].dTexp = 0.000000;
  vrgInputs[ID_IV_dose_rate].dDecay = 0.000000;
  vrgInputs[ID_IV_dose_rate].dTper = 0.000000;
  vrgInputs[ID_IV_dose_rate].hMag = 0;
  vrgInputs[ID_IV_dose_rate].hT0 = 0;
  vrgInputs[ID_IV_dose_rate].hTexp = 0;
  vrgInputs[ID_IV_dose_rate].hDecay = 0;
  vrgInputs[ID_IV_dose_rate].hTper = 0;
  vrgInputs[ID_IV_dose_rate].dVal = 0.0;
  vrgInputs[ID_IV_dose_rate].nDoses = 0;
  G_immediate = 1;
  G_delayed = 0;
  Period = 12.0;
  TChng = 0.01;
  Kr = 0;
  Ka = 0;
  Ke = 0;
  lnKr = log(1.0);
  lnKa = log(1.0);
  lnKe = log(0.05);
  V_central = 0;
  lnV_central = log(0.3);
  Kc2p = 0;
  Kp2c = 0;
  lnKc2p = log(11);
  lnKp2c = log(5);
  M_lnKr = 0;
  M_lnKa = 0;
  M_lnKe = 0;
  M_lnV_central = 0;
  M_lnKc2p = 0;
  M_lnKp2c = 0;
  Vr_lnKr = 0;
  Vr_lnKa = 0;
  Vr_lnKe = 0;
  Vr_lnV_central = 0;
  Vr_lnKc2p = 0;
  Vr_lnKp2c = 0;
  Va_lnKr = 0;
  Va_lnKa = 0;
  Va_lnKe = 0;
  Va_lnV_central = 0;
  Va_lnKc2p = 0;
  Va_lnKp2c = 0;
  Ve_lnC_central = 0;

  vbModelReinitd = TRUE;

} /* InitModel */


/*----- Dynamics section */

void CalcDeriv (double  rgModelVars[], double  rgDerivs[], PDOUBLE pdTime)
{
  /* local */ double PO_dose_rate;

  CalcInputs (pdTime); /* Get new input vals */


  PO_dose_rate = vrgInputs[ID_PO_dose].dVal / TChng ;

  rgDerivs[ID_Q_to_release] = ( G_immediate > 0.5 ? -1 : ( G_delayed > 0.5 ? PO_dose_rate - Kr * rgModelVars[ID_Q_to_release] : 0.0 ) ) ;

  rgDerivs[ID_Q_gi] = ( G_immediate > 0.5 ? PO_dose_rate : ( G_delayed > 0.5 ? Kr * rgModelVars[ID_Q_to_release] : 0.0 ) ) - Ka * rgModelVars[ID_Q_gi] ;

  rgDerivs[ID_Q_elim] = Ke * rgModelVars[ID_Q_central] ;

  rgDerivs[ID_Q_periph] = Kc2p * rgModelVars[ID_Q_central] - Kp2c * rgModelVars[ID_Q_periph] ;

  rgDerivs[ID_Q_central] = vrgInputs[ID_IV_dose_rate].dVal + Ka * rgModelVars[ID_Q_gi] - rgDerivs[ID_Q_elim] - rgDerivs[ID_Q_periph] ;

} /* CalcDeriv */


/*----- Model scaling */

void ScaleModel (PDOUBLE pdTime)
{

  Kr = exp ( lnKr ) ;
  Ka = exp ( lnKa ) ;
  V_central = exp ( lnV_central ) ;
  Kc2p = exp ( lnKc2p ) ;
  Kp2c = exp ( lnKp2c ) ;
  Ke = exp ( lnKe ) ;

} /* ScaleModel */


/*----- Jacobian calculations */

void CalcJacob (PDOUBLE pdTime, double rgModelVars[],
                long column, double rgdJac[])
{

} /* CalcJacob */


/*----- Outputs calculations */

void CalcOutputs (double  rgModelVars[], double  rgDerivs[], PDOUBLE pdTime)
{

  rgModelVars[ID_C_central] = ( rgModelVars[ID_Q_central] < 0 ? 0 : rgModelVars[ID_Q_central] / V_central ) ;

  rgModelVars[ID_Q_total] = ( G_immediate > 0.5 ? ( rgModelVars[ID_Q_gi] + rgModelVars[ID_Q_central] + rgModelVars[ID_Q_periph] + rgModelVars[ID_Q_elim] ) : ( G_delayed > 0.5 ? rgModelVars[ID_Q_to_release] + rgModelVars[ID_Q_gi] + rgModelVars[ID_Q_central] + rgModelVars[ID_Q_periph] + rgModelVars[ID_Q_elim] : 0.0 ) ) ;

  rgModelVars[ID_lnQ_to_release] = ( rgModelVars[ID_Q_to_release] < 0 ? -50 : log ( rgModelVars[ID_Q_to_release] ) ) ;
  rgModelVars[ID_lnQ_gi] = ( rgModelVars[ID_Q_gi] < 0 ? -50 : log ( rgModelVars[ID_Q_gi] ) ) ;
  rgModelVars[ID_lnQ_periph] = ( rgModelVars[ID_Q_periph] < 0 ? -50 : log ( rgModelVars[ID_Q_periph] ) ) ;
  rgModelVars[ID_lnQ_elim] = ( rgModelVars[ID_Q_elim] < 0 ? -50 : log ( rgModelVars[ID_Q_elim] ) ) ;
  rgModelVars[ID_lnQ_total] = ( rgModelVars[ID_Q_total] < 0 ? -50 : log ( rgModelVars[ID_Q_total] ) ) ;
  rgModelVars[ID_lnC_central] = log ( rgModelVars[ID_C_central] ) ;

}  /* CalcOutputs */


